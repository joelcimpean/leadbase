"use client";

import {
  useCallback,
  useEffect,
  useMemo,
  useState,
} from "react";

import Link from "next/link";

import {
  CalendarDays,
  Clock3,
  Flame,
  ListTodo,
  Play,
  Square,
} from "lucide-react";

import {
  useLanguage,
} from "@/components/language-provider";

import {
  Button,
} from "@/components/ui/button";

import {
  Card,
  CardContent,
} from "@/components/ui/card";

import {
  Input,
} from "@/components/ui/input";

type TimerSession = {
  id: string;
  title: string | null;
  project_id: string | null;
  started_at: string;
  ended_at: string | null;
};

type ProjectOption = {
  id: string;
  project_name: string;
  client_name: string;
  status: string;
};

type ActivityDay = {
  activity_date: string;
  opens: number;
  active_minutes: number;
  actions: number;
  score: number;
};

type ProductivityResponse = {
  ok: boolean;
  error?: string;
  localDate?: string;
  todaySeconds?: number;
  openSession?: TimerSession | null;
  projects?: ProjectOption[];
  activity?: ActivityDay[];
};

function formatDuration(
  totalSeconds: number
) {
  const safe =
    Math.max(
      0,
      Math.floor(
        totalSeconds
      )
    );

  const hours =
    Math.floor(
      safe /
        3600
    );

  const minutes =
    Math.floor(
      safe %
        3600 /
        60
    );

  const seconds =
    safe % 60;

  if (
    hours > 0
  ) {
    return `${String(
      hours
    ).padStart(2, "0")}:${String(
      minutes
    ).padStart(2, "0")}:${String(
      seconds
    ).padStart(2, "0")}`;
  }

  return `${String(
    minutes
  ).padStart(2, "0")}:${String(
    seconds
  ).padStart(2, "0")}`;
}

function getLocalDateKey(
  date: Date
) {
  const year =
    date.getFullYear();

  const month =
    String(
      date.getMonth() + 1
    ).padStart(2, "0");

  const day =
    String(
      date.getDate()
    ).padStart(2, "0");

  return `${year}-${month}-${day}`;
}

function getHeatClass(
  score: number
) {
  if (
    score <= 0
  ) {
    return "bg-muted/55 ring-1 ring-inset ring-border/50";
  }

  if (
    score < 8
  ) {
    return "bg-primary/15 ring-1 ring-inset ring-primary/10";
  }

  if (
    score < 20
  ) {
    return "bg-primary/30 ring-1 ring-inset ring-primary/15";
  }

  if (
    score < 40
  ) {
    return "bg-primary/55 ring-1 ring-inset ring-primary/20";
  }

  return "bg-primary ring-1 ring-inset ring-primary/30";
}

function buildHeatmapDays() {
  const today =
    new Date();

  today.setHours(
    0,
    0,
    0,
    0
  );

  const dayOfWeek =
    (today.getDay() + 6) % 7;

  const currentMonday =
    new Date(
      today
    );

  currentMonday.setDate(
    currentMonday.getDate() -
      dayOfWeek
  );

  const start =
    new Date(
      currentMonday
    );

  start.setDate(
    start.getDate() -
      11 * 7
  );

  return Array.from(
    {
      length: 84,
    },
    (
      _,
      index
    ) => {
      const date =
        new Date(
          start
        );

      date.setDate(
        start.getDate() +
          index
      );

      return {
        date,
        key:
          getLocalDateKey(
            date
          ),
        future:
          date.getTime() >
          today.getTime(),
      };
    }
  );
}

function calculateStreak(
  activity:
    ActivityDay[]
) {
  const activeDates =
    new Set(
      activity
        .filter(
          (
            day
          ) =>
            Number(
              day.score ??
                0
            ) > 0
        )
        .map(
          (
            day
          ) =>
            day.activity_date
        )
    );

  const today =
    new Date();

  today.setHours(
    0,
    0,
    0,
    0
  );

  let cursor =
    new Date(
      today
    );

  if (
    !activeDates.has(
      getLocalDateKey(
        cursor
      )
    )
  ) {
    cursor.setDate(
      cursor.getDate() -
        1
    );
  }

  let streak =
    0;

  while (
    activeDates.has(
      getLocalDateKey(
        cursor
      )
    )
  ) {
    streak += 1;
    cursor.setDate(
      cursor.getDate() -
        1
    );
  }

  return streak;
}

export function DashboardProductivity() {
  const {
    language,
  } =
    useLanguage();

  const de =
    language ===
    "de";

  const [
    data,
    setData,
  ] =
    useState<ProductivityResponse | null>(
      null
    );

  const [
    title,
    setTitle,
  ] =
    useState(
      ""
    );

  const [
    projectId,
    setProjectId,
  ] =
    useState(
      ""
    );

  const [
    busy,
    setBusy,
  ] =
    useState(
      false
    );

  const [
    tick,
    setTick,
  ] =
    useState(
      Date.now()
    );


  const [
    loadedAt,
    setLoadedAt,
  ] =
    useState(
      Date.now()
    );

  const load =
    useCallback(
      async () => {
        try {
          const response =
            await fetch(
              `/api/productivity?tzOffset=${encodeURIComponent(
                String(
                  new Date()
                    .getTimezoneOffset()
                )
              )}`,
              {
                cache:
                  "no-store",
              }
            );

          const result =
            (await response.json()) as ProductivityResponse;

          if (
            response.ok &&
            result.ok
          ) {
            setData(
              result
            );
            setLoadedAt(
              Date.now()
            );
          }
        } catch {
          // Dashboard remains usable if productivity data fails.
        }
      },
      []
    );

  useEffect(
    () => {
      void load();

      const interval =
        window.setInterval(
          () => {
            void load();
          },
          5 * 60 * 1000
        );

      return () =>
        window.clearInterval(
          interval
        );
    },
    [
      load,
    ]
  );

  useEffect(
    () => {
      if (
        !data?.openSession
      ) {
        return;
      }

      const interval =
        window.setInterval(
          () => {
            setTick(
              Date.now()
            );
          },
          1000
        );

      return () =>
        window.clearInterval(
          interval
        );
    },
    [
      data?.openSession,
    ]
  );

  const activeSeconds =
    data?.openSession
      ? Math.max(
          0,
          Math.floor(
            (tick -
              new Date(
                data.openSession.started_at
              ).getTime()) /
              1000
          )
        )
      : 0;

  const baseTodaySeconds =
    Math.max(
      0,
      Number(
        data?.todaySeconds ??
          0
      )
    );

  const todaySeconds =
    baseTodaySeconds +
    (data?.openSession
      ? Math.max(
          0,
          Math.floor(
            (tick - loadedAt) /
              1000
          )
        )
      : 0);

  const projects =
    data?.projects ??
    [];

  const projectById =
    useMemo(
      () =>
        new Map(
          projects.map(
            (
              project
            ) => [
              project.id,
              project,
            ]
          )
        ),
      [
        projects,
      ]
    );

  const heatDays =
    useMemo(
      () =>
        buildHeatmapDays(),
      []
    );

  const activityMap =
    useMemo(
      () =>
        new Map(
          (data?.activity ??
            []).map(
              (
                day
              ) => [
                day.activity_date,
                day,
              ]
            )
        ),
      [
        data?.activity,
      ]
    );

  const streak =
    useMemo(
      () =>
        calculateStreak(
          data?.activity ??
            []
        ),
      [
        data?.activity,
      ]
    );

  async function startTimer() {
    if (
      busy
    ) {
      return;
    }

    setBusy(
      true
    );

    try {
      const response =
        await fetch(
          "/api/productivity",
          {
            method:
              "POST",
            headers: {
              "Content-Type":
                "application/json",
            },
            body:
              JSON.stringify({
                action:
                  "start_timer",
                title,
                projectId:
                  projectId ||
                  null,
              }),
          }
        );

      if (
        response.ok
      ) {
        setTitle(
          ""
        );
        setTick(
          Date.now()
        );
        await load();
      }
    } finally {
      setBusy(
        false
      );
    }
  }

  async function stopTimer() {
    if (
      busy
    ) {
      return;
    }

    setBusy(
      true
    );

    try {
      const response =
        await fetch(
          "/api/productivity",
          {
            method:
              "POST",
            headers: {
              "Content-Type":
                "application/json",
            },
            body:
              JSON.stringify({
                action:
                  "stop_timer",
              }),
          }
        );

      if (
        response.ok
      ) {
        await load();
      }
    } finally {
      setBusy(
        false
      );
    }
  }

  const activeProject =
    data?.openSession
      ?.project_id
      ? projectById.get(
          data.openSession.project_id
        ) ??
        null
      : null;

  return (
    <section
      data-leadbase-reveal
      className="mt-4 grid gap-4 xl:grid-cols-[0.8fr_1.2fr]"
    >
      <Card className="leadbase-panel min-w-0 border-border/70">
        <CardContent className="p-4 sm:p-5">
          <div className="flex items-start justify-between gap-4">
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <Clock3 className="size-4 text-primary" />

                <h2 className="text-sm font-semibold">
                  {de
                    ? "Time Tracker"
                    : "Time tracker"}
                </h2>
              </div>

              <p className="mt-1 text-xs leading-5 text-muted-foreground">
                {de
                  ? "Fokuszeit direkt einem Projekt zuordnen."
                  : "Track focus time and optionally attach it to a project."}
              </p>
            </div>

            <div className="shrink-0 text-right">
              <p className="text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
                {de
                  ? "Heute"
                  : "Today"}
              </p>

              <p className="mt-1 font-mono text-sm font-semibold tabular-nums">
                {formatDuration(
                  todaySeconds
                )}
              </p>
            </div>
          </div>

          {data?.openSession ? (
            <div className="mt-5 rounded-xl border border-primary/20 bg-primary/[0.045] p-4">
              <div className="flex items-center gap-2 text-primary">
                <span className="size-2 rounded-full bg-primary shadow-[0_0_0_5px_color-mix(in_srgb,var(--primary)_12%,transparent)]" />
                <span className="text-xs font-semibold">
                  {de
                    ? "Läuft"
                    : "Running"}
                </span>
              </div>

              <p className="mt-3 truncate text-sm font-semibold">
                {data.openSession.title ||
                  activeProject?.project_name ||
                  (de
                    ? "Fokus-Session"
                    : "Focus session")}
              </p>

              {activeProject ? (
                <p className="mt-1 truncate text-xs text-muted-foreground">
                  {activeProject.client_name}
                </p>
              ) : null}

              <p className="mt-5 font-mono text-3xl font-semibold tracking-[-0.04em] tabular-nums">
                {formatDuration(
                  activeSeconds
                )}
              </p>

              <Button
                type="button"
                variant="outline"
                disabled={
                  busy
                }
                onClick={
                  stopTimer
                }
                className="mt-4 w-full gap-2"
              >
                <Square className="size-3.5 fill-current" />
                {de
                  ? "Timer stoppen"
                  : "Stop timer"}
              </Button>
            </div>
          ) : (
            <div className="mt-5 space-y-3">
              <Input
                value={
                  title
                }
                onChange={(
                  event
                ) =>
                  setTitle(
                    event.target.value
                  )
                }
                placeholder={
                  de
                    ? "Woran arbeitest du?"
                    : "What are you working on?"
                }
                maxLength={
                  140
                }
              />

              <select
                value={
                  projectId
                }
                onChange={(
                  event
                ) =>
                  setProjectId(
                    event.target.value
                  )
                }
                className="h-10 w-full rounded-lg border border-border/70 bg-background px-3 text-sm outline-none transition focus:border-primary/40 focus:ring-2 focus:ring-primary/15"
              >
                <option value="">
                  {de
                    ? "Kein Projekt"
                    : "No project"}
                </option>

                {projects.map(
                  (
                    project
                  ) => (
                    <option
                      key={
                        project.id
                      }
                      value={
                        project.id
                      }
                    >
                      {project.project_name} · {project.client_name}
                    </option>
                  )
                )}
              </select>

              <Button
                type="button"
                disabled={
                  busy
                }
                onClick={
                  startTimer
                }
                className="w-full gap-2"
              >
                <Play className="size-3.5 fill-current" />
                {de
                  ? "Timer starten"
                  : "Start timer"}
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      <Card className="leadbase-panel min-w-0 border-border/70">
        <CardContent className="p-4 sm:p-5">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <Flame className="size-4 text-primary" />

                <h2 className="text-sm font-semibold">
                  {de
                    ? "Tagesstreak"
                    : "Daily streak"}
                </h2>
              </div>

              <p className="mt-1 text-xs leading-5 text-muted-foreground">
                {de
                  ? "Je aktiver du Leadbase nutzt, desto intensiver wird der Tag."
                  : "The more you work in Leadbase, the stronger each day becomes."}
              </p>
            </div>

            <div className="flex items-center gap-3">
              <div className="rounded-xl border border-primary/15 bg-primary/[0.05] px-3 py-2 text-center">
                <p className="text-lg font-semibold text-primary">
                  {streak}
                </p>
                <p className="text-[10px] uppercase tracking-[0.12em] text-muted-foreground">
                  {de
                    ? "Tage"
                    : "days"}
                </p>
              </div>

              <Link
                href="/reminders"
                className="flex h-10 items-center gap-2 rounded-xl border border-border/70 px-3 text-xs font-medium text-muted-foreground transition hover:border-primary/20 hover:bg-primary/[0.04] hover:text-primary"
              >
                <ListTodo className="size-3.5" />
                {de
                  ? "Reminders"
                  : "Reminders"}
              </Link>
            </div>
          </div>

          <div className="mt-6 overflow-x-auto pb-1">
            <div className="grid w-max grid-flow-col grid-rows-7 gap-1.5">
              {heatDays.map(
                (
                  day
                ) => {
                  const activity =
                    activityMap.get(
                      day.key
                    );

                  const score =
                    Number(
                      activity?.score ??
                        0
                    );

                  return (
                    <div
                      key={
                        day.key
                      }
                      title={
                        day.future
                          ? ""
                          : `${day.date.toLocaleDateString(
                              de
                                ? "de-DE"
                                : "en-GB"
                            )} · ${Number(activity?.opens ?? 0)} ${de ? "Öffnungen" : "opens"} · ${Number(activity?.active_minutes ?? 0)} min · ${Number(activity?.actions ?? 0)} ${de ? "Aktionen" : "actions"}`
                      }
                      className={`size-3 rounded-[3px] transition-transform duration-150 hover:scale-125 ${
                        day.future
                          ? "opacity-0"
                          : getHeatClass(
                              score
                            )
                      }`}
                    />
                  );
                }
              )}
            </div>
          </div>

          <div className="mt-4 flex flex-wrap items-center justify-between gap-3 text-[11px] text-muted-foreground">
            <span className="flex items-center gap-1.5">
              <CalendarDays className="size-3.5" />
              {de
                ? "Letzte 12 Wochen"
                : "Last 12 weeks"}
            </span>

            <span className="flex items-center gap-1.5">
              {de
                ? "Weniger"
                : "Less"}
              <i className="size-2.5 rounded-[3px] bg-muted" />
              <i className="size-2.5 rounded-[3px] bg-primary/20" />
              <i className="size-2.5 rounded-[3px] bg-primary/50" />
              <i className="size-2.5 rounded-[3px] bg-primary" />
              {de
                ? "Mehr"
                : "More"}
            </span>
          </div>
        </CardContent>
      </Card>
    </section>
  );
}
