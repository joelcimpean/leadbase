import {
  redirect,
} from "next/navigation";

import {
  getAppLanguage,
} from "@/lib/i18n-server";

import {
  createClient,
} from "@/lib/supabase/server";

import {
  RemindersClient,
} from "./reminders-client";

export default async function RemindersPage() {
  const [
    supabase,
    language,
  ] =
    await Promise.all([
      createClient(),
      getAppLanguage(),
    ]);

  const {
    data: {
      user,
    },
  } =
    await supabase.auth.getUser();

  if (
    !user
  ) {
    redirect(
      "/login"
    );
  }

  const {
    data,
    error,
  } =
    await supabase
      .from(
        "user_reminders"
      )
      .select(`
        id,
        title,
        note,
        due_at,
        completed_at,
        created_at,
        updated_at
      `)
      .eq(
        "user_id",
        user.id
      )
      .order(
        "completed_at",
        {
          ascending:
            true,
          nullsFirst:
            true,
        }
      )
      .order(
        "due_at",
        {
          ascending:
            true,
          nullsFirst:
            false,
        }
      )
      .order(
        "created_at",
        {
          ascending:
            false,
        }
      );

  if (
    error
  ) {
    console.error(
      "Could not load reminders:",
      error
    );
  }

  return (
    <RemindersClient
      initialReminders={
        data ??
        []
      }
      language={
        language
      }
    />
  );
}
