"use client";

import Link from "next/link";

import {
  useEffect,
  useMemo,
  useRef,
  useState,
  useTransition,
} from "react";

import {
  useRouter,
} from "next/navigation";

import {
  CalendarClock,
  CalendarX2,
  ChevronDown,
  ChevronRight,
  ExternalLink,
  Eye,
  Folder,
  FolderOpen,
  GripVertical,
  LayoutList,
  Loader2,
  Mail,
  MapPin,
  MoreHorizontal,
  Pencil,
  Search,
  SlidersHorizontal,
  Sparkles,
  Table2,
  Trash2,
  WandSparkles,
  X,
  MailPlus,
} from "lucide-react";


import {
  cancelScheduledOutreachForBulk,
  generateLeadOutreachDraftForBulk,
} from "./outreach-actions";

import {
  BulkOutreachScheduleDialog,
} from "./bulk-outreach-schedule-dialog";

import {
  bulkDeleteLeads,
} from "./bulk-actions";

import {
  LeadPreviewVisitsButton,
  type LeadPreviewSummary,
} from "./lead-preview-visits-button";

import {
  LeadHotScoreIndicator,
  type HotLeadSummary,
} from "./lead-hot-score-indicator";

import {
  useLanguage,
} from "@/components/language-provider";

import {
  useAppNotifications,
} from "@/components/app-notifications";

import {
  useAppBackgroundTasks,
} from "@/components/app-background-tasks";

import {
  createClient as createBrowserSupabaseClient,
} from "@/lib/supabase/client";

import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

import {
  Badge,
} from "@/components/ui/badge";

import {
  Button,
} from "@/components/ui/button";

import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

import {
  Input,
} from "@/components/ui/input";

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

import {
  getLeadPriorityLabel,
  getLeadStatusLabel,
  leadsCopy,
} from "@/lib/leads-i18n";

/* =========================================================
   TYPES
========================================================= */

export type LeadTableRow = {
  id:
    string;

  companyName:
    string;

  industry:
    | string
    | null;

  location:
    | string
    | null;

  websiteUrl:
    | string
    | null;

  contactFormUrl:
    | string
    | null;

  contactEmail:
    | string
    | null;

  websiteScore:
    | number
    | null;

  opportunityScore:
    | number
    | null;

  status:
    string;

  priority:
    | string
    | null;

  analysisStatus:
    | string
    | null;

  lastContactedAt:
    | string
    | null;

  createdAt:
    string;

  sortOrder:
    | number
    | null;

  campaignId:
    | string
    | null;

  campaignName:
    | string
    | null;
};

type Progress = {
  current:
    number;

  total:
    number;
};

type ViewMode =
  | "compact"
  | "table";

type ShareCreateResponse = {
  ok?:
    boolean;

  shared?:
    boolean;

  shareUrl?:
    string;

  error?:
    string;
};

type PreviewGifGenerationResponse = {
  ok?:
    boolean;

  status?:
    string;

  gifUrl?:
    string;

  error?:
    string;
};

type DesignResponse = {
  ok?:
    boolean;

  generated?:
    boolean;

  error?:
    string;
};

/* =========================================================
   STATUS
========================================================= */

function statusClass(
  status:
    string
) {
  switch (
    status
  ) {
    case "NEW":
      return "border-sky-200 bg-sky-50 text-sky-700 dark:border-sky-900 dark:bg-sky-950/40 dark:text-sky-400";

    case "RESEARCHING":
      return "border-amber-200 bg-amber-50 text-amber-700 dark:border-amber-900 dark:bg-amber-950/40 dark:text-amber-400";

    case "QUALIFIED":
      return "border-emerald-200 bg-emerald-50 text-emerald-700 dark:border-emerald-900 dark:bg-emerald-950/40 dark:text-emerald-400";

    case "DRAFT_READY":
      return "border-violet-200 bg-violet-50 text-violet-700 dark:border-violet-900 dark:bg-violet-950/40 dark:text-violet-400";

    case "CONTACTED":
      return "border-blue-200 bg-blue-50 text-blue-700 dark:border-blue-900 dark:bg-blue-950/40 dark:text-blue-400";

    case "REPLIED":
      return "border-cyan-200 bg-cyan-50 text-cyan-700 dark:border-cyan-900 dark:bg-cyan-950/40 dark:text-cyan-400";

    case "CALL_BOOKED":
      return "border-indigo-200 bg-indigo-50 text-indigo-700 dark:border-indigo-900 dark:bg-indigo-950/40 dark:text-indigo-400";

    case "PROPOSAL":
      return "border-purple-200 bg-purple-50 text-purple-700 dark:border-purple-900 dark:bg-purple-950/40 dark:text-purple-400";

    case "WON":
      return "border-green-200 bg-green-50 text-green-700 dark:border-green-900 dark:bg-green-950/40 dark:text-green-400";

    case "DO_NOT_CONTACT":
      return "border-red-200 bg-red-50 text-red-700 dark:border-red-900 dark:bg-red-950/40 dark:text-red-400";

    default:
      return "border-zinc-200 bg-zinc-50 text-zinc-700 dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-300";
  }
}

/* =========================================================
   PRIORITY
========================================================= */

function priorityClass(
  priority:
    | string
    | null
) {
  switch (
    priority
  ) {
    case "HIGH":
      return "text-red-600 dark:text-red-400";

    case "MEDIUM":
      return "text-amber-600 dark:text-amber-400";

    default:
      return "text-muted-foreground";
  }
}

/* =========================================================
   DATE
========================================================= */

function formatDate(
  value:
    | string
    | null,
  language:
    string
) {
  if (
    !value
  ) {
    return "—";
  }

  return new Intl.DateTimeFormat(
    language ===
      "de"
      ? "de-DE"
      : "en-IE",
    {
      day:
        "2-digit",

      month:
        "short",
    }
  ).format(
    new Date(
      value
    )
  );
}

/* =========================================================
   URL
========================================================= */

function normalizeUrl(
  value:
    string
) {
  return value.startsWith(
    "http"
  )
    ? value
    : `https://${value}`;
}

/* =========================================================
   CHECKBOX
========================================================= */

function SelectionCheckbox({
  checked,
  indeterminate =
    false,
  disabled =
    false,
  label,
  onChange,
}: {
  checked:
    boolean;

  indeterminate?:
    boolean;

  disabled?:
    boolean;

  label:
    string;

  onChange:
    () => void;
}) {
  const ref =
    useRef<HTMLInputElement>(
      null
    );

  useEffect(
    () => {
      if (
        ref.current
      ) {
        ref.current.indeterminate =
          indeterminate;
      }
    },
    [
      indeterminate,
    ]
  );

  return (
    <input
      ref={
        ref
      }
      type="checkbox"
      checked={
        checked
      }
      disabled={
        disabled
      }
      aria-label={
        label
      }
      onChange={
        onChange
      }
      className="size-4 cursor-pointer rounded border-border accent-foreground disabled:cursor-not-allowed disabled:opacity-50"
    />
  );
}

/* =========================================================
   COMPONENT
========================================================= */

export function LeadsTable({
  leads,
  groupOrder,
}: {
  leads:
    LeadTableRow[];

  groupOrder:
    Record<string, number>;
}) {
  const router =
    useRouter();

  const {
    language,
  } =
    useLanguage();

  const {
    notify,
  } =
    useAppNotifications();

  const {
    analysisTask,
    startBulkAnalysis,
    startBulkDesignTask,
    updateBulkDesignTask,
    finishBulkDesignTask,
  } =
    useAppBackgroundTasks();

  const text =
    leadsCopy[
      language
    ];

  const ui =
    language ===
    "de"
      ? {
          compact:
            "Kompakt",

          table:
            "Tabelle",

          uncategorized:
            "Ohne Kampagne",

          generateDesigns:
            "Designs erstellen",

          generating:
            "Designs werden erstellt",

          noDesignEligible:
            "Keiner der ausgewählten Leads kann aktuell designt werden. Die Website muss zuerst vollständig analysiert sein.",

          designsFinished:
            "Design-Erstellung abgeschlossen",

          created:
            "neu erstellt",

          existing:
            "bereits vorhanden",

          skipped:
            "übersprungen",

          failed:
            "fehlgeschlagen",

          analyzed:
            "Analysiert",

          notAnalyzed:
            "Nicht analysiert",

          campaign:
            "Kampagne",

          scores:
            "Scores",

          contact:
            "Kontakt",

          open:
            "Öffnen",

          leads:
            "Leads",

          previewViews:
            "Vorschau",
        }
      : {
          compact:
            "Compact",

          table:
            "Table",

          uncategorized:
            "No campaign",

          generateDesigns:
            "Generate designs",

          generating:
            "Generating designs",

          noDesignEligible:
            "None of the selected leads can currently be designed. The website must be fully analyzed first.",

          designsFinished:
            "Design generation complete",

          created:
            "created",

          existing:
            "already existed",

          skipped:
            "skipped",

          failed:
            "failed",

          analyzed:
            "Analyzed",

          notAnalyzed:
            "Not analyzed",

          campaign:
            "Campaign",

          scores:
            "Scores",

          contact:
            "Contact",

          open:
            "Open",

          leads:
            "Leads",

          previewViews:
            "Preview",
        };

  /* =======================================================
     CUSTOMER PREVIEW SUMMARIES
  ======================================================= */

  const [
    previewSummaries,
    setPreviewSummaries,
  ] =
    useState<
      Record<
        string,
        LeadPreviewSummary
      >
    >(
      {}
    );

  useEffect(
    () => {
      const controller =
        new AbortController();

      async function loadPreviewSummaries() {
        try {
          const response =
            await fetch(
              "/api/leads/preview-visits-summary",
              {
                cache:
                  "no-store",

                signal:
                  controller.signal,
              }
            );

          const contentType =
            response.headers.get(
              "content-type"
            ) ??
            "";

          if (
            !response.ok ||
            !contentType.includes(
              "application/json"
            )
          ) {
            return;
          }

          const result =
            (await response.json()) as {
              ok?:
                boolean;

              previews?:
                Record<
                  string,
                  LeadPreviewSummary
                >;
            };

          if (
            !result.ok
          ) {
            return;
          }

          setPreviewSummaries(
            result.previews ??
              {}
          );
        } catch (
          loadError
        ) {
          if (
            loadError instanceof
              DOMException &&
            loadError.name ===
              "AbortError"
          ) {
            return;
          }

          console.error(
            "Could not load preview summaries:",
            loadError
          );
        }
      }

      void loadPreviewSummaries();

      return () => {
        controller.abort();
      };
    },
    []
  );

  /* =======================================================
     HOT LEAD SCORES
  ======================================================= */

  const [
    hotLeadSummaries,
    setHotLeadSummaries,
  ] =
    useState<
      Record<
        string,
        HotLeadSummary
      >
    >(
      {}
    );

  useEffect(
    () => {
      const controller =
        new AbortController();

      async function loadHotLeadScores() {
        try {
          const response =
            await fetch(
              "/api/leads/hot-scores",
              {
                cache:
                  "no-store",

                signal:
                  controller.signal,
              }
            );

          const contentType =
            response.headers.get(
              "content-type"
            ) ??
            "";

          if (
            !response.ok ||
            !contentType.includes(
              "application/json"
            )
          ) {
            return;
          }

          const result =
            (await response.json()) as {
              ok?:
                boolean;

              leads?:
                Record<
                  string,
                  HotLeadSummary
                >;
            };

          if (
            !result.ok
          ) {
            return;
          }

          setHotLeadSummaries(
            result.leads ??
              {}
          );
        } catch (
          loadError
        ) {
          if (
            loadError instanceof
              DOMException &&
            loadError.name ===
              "AbortError"
          ) {
            return;
          }

          console.error(
            "Could not load hot lead scores:",
            loadError
          );
        }
      }

      void loadHotLeadScores();

      return () => {
        controller.abort();
      };
    },
    []
  );

  /* =======================================================
     VIEW
  ======================================================= */

  const [
    viewMode,
    setViewMode,
  ] =
    useState<ViewMode>(
      "compact"
    );

  useEffect(
    () => {
      const stored =
        window.localStorage.getItem(
          "leadbase-leads-view"
        );

      if (
        stored ===
          "compact" ||
        stored ===
          "table"
      ) {
        setViewMode(
          stored
        );
      }
    },
    []
  );

  function changeView(
    value:
      ViewMode
  ) {
    setViewMode(
      value
    );

    window.localStorage.setItem(
      "leadbase-leads-view",
      value
    );
  }

  /* =======================================================
     FILTER
  ======================================================= */

  const [
    search,
    setSearch,
  ] =
    useState(
      ""
    );

  const [
    status,
    setStatus,
  ] =
    useState(
      "ALL"
    );

  const [
    priority,
    setPriority,
  ] =
    useState(
      "ALL"
    );

  const [
    filtersOpen,
    setFiltersOpen,
  ] =
    useState(
      false
    );

  const filteredLeads =
    useMemo(
      () => {
        const searchTerm =
          search
            .trim()
            .toLowerCase();

        return leads.filter(
          (
            lead
          ) => {
            const matchesSearch =
              !searchTerm ||
              lead.companyName
                .toLowerCase()
                .includes(
                  searchTerm
                ) ||
              lead.industry
                ?.toLowerCase()
                .includes(
                  searchTerm
                ) ||
              lead.location
                ?.toLowerCase()
                .includes(
                  searchTerm
                ) ||
              lead.campaignName
                ?.toLowerCase()
                .includes(
                  searchTerm
                ) ||
              lead.contactEmail
                ?.toLowerCase()
                .includes(
                  searchTerm
                );

            const matchesStatus =
              status ===
                "ALL" ||
              lead.status ===
                status;

            const matchesPriority =
              priority ===
                "ALL" ||
              (
                priority ===
                  "NONE"
                  ? lead.priority ===
                    null
                  : lead.priority ===
                    priority
              );

            return (
              matchesSearch &&
              matchesStatus &&
              matchesPriority
            );
          }
        );
      },
      [
        leads,
        search,
        status,
        priority,
      ]
    );

  const hasActiveFilters =
    search.trim() !==
      "" ||
    status !==
      "ALL" ||
    priority !==
      "ALL";

  function resetFilters() {
    setSearch(
      ""
    );

    setStatus(
      "ALL"
    );

    setPriority(
      "ALL"
    );
  }

  /* =======================================================
     CAMPAIGN GROUPS + MANUAL ORDER
  ======================================================= */

  const [
    leadOrderOverrides,
    setLeadOrderOverrides,
  ] = useState<Record<string, number>>({});

  const [
    groupOrderState,
    setGroupOrderState,
  ] = useState<Record<string, number>>(
    groupOrder
  );

  const [
    draggedLeadId,
    setDraggedLeadId,
  ] = useState<string | null>(null);

  const [
    draggedGroupKey,
    setDraggedGroupKey,
  ] = useState<string | null>(null);

  const [
    leadDropTarget,
    setLeadDropTarget,
  ] = useState<{
    groupKey: string;
    targetId: string;
    placeAfter: boolean;
  } | null>(null);

  const [
    groupDropTarget,
    setGroupDropTarget,
  ] = useState<{
    targetKey: string;
    placeAfter: boolean;
  } | null>(null);

  const browserSupabaseRef = useRef<
    ReturnType<typeof createBrowserSupabaseClient> | null
  >(null);

  const leadSaveQueueRef = useRef<
    Record<
      string,
      {
        desired: string[];
        timer: ReturnType<typeof setTimeout> | null;
        inFlight: boolean;
      }
    >
  >({});

  const groupSaveQueueRef = useRef<{
    desired: string[];
    timer: ReturnType<typeof setTimeout> | null;
    inFlight: boolean;
  }>({
    desired: [],
    timer: null,
    inFlight: false,
  });

  function getBrowserSupabase() {
    if (!browserSupabaseRef.current) {
      browserSupabaseRef.current =
        createBrowserSupabaseClient();
    }

    return browserSupabaseRef.current;
  }

  useEffect(() => {
    setGroupOrderState(
      groupOrder
    );
  }, [groupOrder]);

  useEffect(() => {
    return () => {
      Object.values(
        leadSaveQueueRef.current
      ).forEach((entry) => {
        if (entry.timer) {
          clearTimeout(entry.timer);
        }
      });

      if (
        groupSaveQueueRef.current.timer
      ) {
        clearTimeout(
          groupSaveQueueRef.current.timer
        );
      }
    };
  }, []);

  const groups = useMemo(() => {
    const map = new Map<
      string,
      {
        key: string;
        name: string;
        leads: LeadTableRow[];
        initialIndex: number;
      }
    >();

    let groupIndex = 0;

    for (const lead of filteredLeads) {
      const key =
        lead.campaignId ??
        "__none__";

      const existing =
        map.get(key);

      if (existing) {
        existing.leads.push(lead);
        continue;
      }

      map.set(key, {
        key,
        name:
          lead.campaignName ??
          ui.uncategorized,
        leads: [lead],
        initialIndex:
          groupIndex++,
      });
    }

    const list =
      Array.from(map.values());

    for (const group of list) {
      group.leads.sort((a, b) => {
        const aOverride =
          leadOrderOverrides[a.id];
        const bOverride =
          leadOrderOverrides[b.id];

        const aOrder =
          aOverride ??
          a.sortOrder;
        const bOrder =
          bOverride ??
          b.sortOrder;

        if (
          aOrder !== null &&
          aOrder !== undefined &&
          bOrder !== null &&
          bOrder !== undefined &&
          aOrder !== bOrder
        ) {
          return aOrder - bOrder;
        }

        if (
          aOrder !== null &&
          aOrder !== undefined
        ) {
          return -1;
        }

        if (
          bOrder !== null &&
          bOrder !== undefined
        ) {
          return 1;
        }

        return (
          Date.parse(b.createdAt) -
          Date.parse(a.createdAt)
        );
      });
    }

    list.sort((a, b) => {
      const aOrder =
        groupOrderState[a.key];
      const bOrder =
        groupOrderState[b.key];

      if (
        aOrder !== undefined &&
        bOrder !== undefined &&
        aOrder !== bOrder
      ) {
        return aOrder - bOrder;
      }

      if (aOrder !== undefined) {
        return -1;
      }

      if (bOrder !== undefined) {
        return 1;
      }

      return (
        a.initialIndex -
        b.initialIndex
      );
    });

    return list;
  }, [
    filteredLeads,
    groupOrderState,
    leadOrderOverrides,
    ui.uncategorized,
  ]);

  const manualSortingEnabled =
    viewMode === "compact" &&
    !hasActiveFilters;

  async function flushLeadOrder(
    groupKey: string
  ) {
    const entry =
      leadSaveQueueRef.current[groupKey];

    if (!entry || entry.inFlight) {
      return;
    }

    entry.inFlight = true;
    const snapshot = [...entry.desired];
    const snapshotKey = snapshot.join("|");

    const { error } =
      await getBrowserSupabase().rpc(
        "reorder_leadbase_leads",
        {
          p_group_key: groupKey,
          p_lead_ids: snapshot,
        }
      );

    entry.inFlight = false;

    if (error) {
      console.error(
        "Lead reorder failed:",
        error
      );

      setLeadOrderOverrides({});
      router.refresh();

      notify({
        title:
          language === "de"
            ? "Reihenfolge nicht gespeichert"
            : "Order not saved",
        description:
          language === "de"
            ? "Die Reihenfolge konnte nicht gespeichert werden."
            : "The order could not be saved.",
        variant: "error",
      });

      return;
    }

    if (
      entry.desired.join("|") !==
      snapshotKey
    ) {
      entry.timer = setTimeout(
        () => void flushLeadOrder(groupKey),
        40
      );
    }
  }

  function persistLeadOrder(
    groupKey: string,
    leadIds: string[]
  ) {
    const nextOverrides: Record<string, number> = {};

    leadIds.forEach((id, index) => {
      nextOverrides[id] =
        (index + 1) * 1000;
    });

    setLeadOrderOverrides((current) => ({
      ...current,
      ...nextOverrides,
    }));

    const existing =
      leadSaveQueueRef.current[groupKey] ?? {
        desired: [],
        timer: null,
        inFlight: false,
      };

    existing.desired = [...leadIds];

    if (existing.timer) {
      clearTimeout(existing.timer);
    }

    existing.timer = setTimeout(
      () => void flushLeadOrder(groupKey),
      140
    );

    leadSaveQueueRef.current[groupKey] =
      existing;
  }

  function moveLeadRelative(
    groupKey: string,
    sourceId: string,
    targetId: string,
    placeAfter: boolean
  ) {
    if (
      sourceId === targetId ||
      !manualSortingEnabled
    ) {
      return;
    }

    const group = groups.find(
      (item) => item.key === groupKey
    );

    if (!group) {
      return;
    }

    const ids = group.leads.map(
      (lead) => lead.id
    );

    const sourceIndex =
      ids.indexOf(sourceId);

    if (sourceIndex < 0) {
      return;
    }

    ids.splice(sourceIndex, 1);

    const targetIndex =
      ids.indexOf(targetId);

    if (targetIndex < 0) {
      return;
    }

    ids.splice(
      targetIndex +
        (placeAfter ? 1 : 0),
      0,
      sourceId
    );

    persistLeadOrder(
      groupKey,
      ids
    );
  }

  async function flushGroupOrder() {
    const queue =
      groupSaveQueueRef.current;

    if (
      queue.inFlight ||
      queue.desired.length === 0
    ) {
      return;
    }

    queue.inFlight = true;
    const snapshot = [...queue.desired];
    const snapshotKey = snapshot.join("|");

    const { error } =
      await getBrowserSupabase().rpc(
        "reorder_leadbase_groups",
        {
          p_group_keys: snapshot,
        }
      );

    queue.inFlight = false;

    if (error) {
      console.error(
        "Lead group reorder failed:",
        error
      );

      setGroupOrderState(groupOrder);
      router.refresh();

      notify({
        title:
          language === "de"
            ? "Gruppenreihenfolge nicht gespeichert"
            : "Group order not saved",
        description:
          language === "de"
            ? "Die Gruppenreihenfolge konnte nicht gespeichert werden."
            : "The group order could not be saved.",
        variant: "error",
      });

      return;
    }

    if (
      queue.desired.join("|") !==
      snapshotKey
    ) {
      queue.timer = setTimeout(
        () => void flushGroupOrder(),
        40
      );
    }
  }

  function persistGroupOrder(
    orderedKeys: string[]
  ) {
    const next: Record<string, number> = {};

    orderedKeys.forEach((key, index) => {
      next[key] =
        (index + 1) * 1000;
    });

    setGroupOrderState(next);

    const queue =
      groupSaveQueueRef.current;

    queue.desired = [...orderedKeys];

    if (queue.timer) {
      clearTimeout(queue.timer);
    }

    queue.timer = setTimeout(
      () => void flushGroupOrder(),
      140
    );
  }

  function moveGroupRelative(
    sourceKey: string,
    targetKey: string,
    placeAfter: boolean
  ) {
    if (
      sourceKey === targetKey ||
      !manualSortingEnabled
    ) {
      return;
    }

    const keys = groups.map(
      (group) => group.key
    );

    const sourceIndex =
      keys.indexOf(sourceKey);

    if (sourceIndex < 0) {
      return;
    }

    keys.splice(sourceIndex, 1);

    const targetIndex =
      keys.indexOf(targetKey);

    if (targetIndex < 0) {
      return;
    }

    keys.splice(
      targetIndex +
        (placeAfter ? 1 : 0),
      0,
      sourceKey
    );

    persistGroupOrder(keys);
  }

  const [
    collapsedGroups,
    setCollapsedGroups,
  ] = useState<Set<string>>(
    () => new Set()
  );

  const [
    collapsedGroupsHydrated,
    setCollapsedGroupsHydrated,
  ] = useState(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(
        "leadbase:leads:collapsed-groups:v1"
      );

      if (raw) {
        const parsed = JSON.parse(raw);

        if (Array.isArray(parsed)) {
          setCollapsedGroups(
            new Set(
              parsed.filter(
                (value): value is string =>
                  typeof value === "string"
              )
            )
          );
        }
      }
    } catch (error) {
      console.warn(
        "Could not restore collapsed lead groups:",
        error
      );
    } finally {
      setCollapsedGroupsHydrated(true);
    }
  }, []);

  useEffect(() => {
    if (!collapsedGroupsHydrated) {
      return;
    }

    try {
      localStorage.setItem(
        "leadbase:leads:collapsed-groups:v1",
        JSON.stringify(
          Array.from(collapsedGroups)
        )
      );
    } catch (error) {
      console.warn(
        "Could not persist collapsed lead groups:",
        error
      );
    }
  }, [
    collapsedGroups,
    collapsedGroupsHydrated,
  ]);

  function toggleGroupOpen(
    key: string
  ) {
    setCollapsedGroups((current) => {
      const next = new Set(current);

      if (next.has(key)) {
        next.delete(key);
      } else {
        next.add(key);
      }

      return next;
    });
  }

  /* =======================================================
     SELECTION
  ======================================================= */

  const [
    selectedIds,
    setSelectedIds,
  ] =
    useState<
      Set<string>
    >(
      () =>
        new Set()
    );

  function toggleLead(
    leadId:
      string
  ) {
    setBulkMessage(
      null
    );

    setSelectedIds(
      (
        current
      ) => {
        const next =
          new Set(
            current
          );

        if (
          next.has(
            leadId
          )
        ) {
          next.delete(
            leadId
          );
        } else {
          next.add(
            leadId
          );
        }

        return next;
      }
    );
  }

  const filteredIds =
    filteredLeads.map(
      (
        lead
      ) =>
        lead.id
    );

  const visibleSelected =
    filteredIds.filter(
      (
        id
      ) =>
        selectedIds.has(
          id
        )
    ).length;

  const allVisibleSelected =
    filteredIds.length >
      0 &&
    visibleSelected ===
      filteredIds.length;

  const someVisibleSelected =
    visibleSelected >
      0 &&
    !allVisibleSelected;

  function toggleAllVisible() {
    setSelectedIds(
      (
        current
      ) => {
        const next =
          new Set(
            current
          );

        for (
          const id of
            filteredIds
        ) {
          if (
            allVisibleSelected
          ) {
            next.delete(
              id
            );
          } else {
            next.add(
              id
            );
          }
        }

        return next;
      }
    );
  }

  function toggleCampaignSelection(
    campaignLeads:
      LeadTableRow[]
  ) {
    const ids =
      campaignLeads.map(
        (
          lead
        ) =>
          lead.id
      );

    const allSelected =
      ids.every(
        (
          id
        ) =>
          selectedIds.has(
            id
          )
      );

    setSelectedIds(
      (
        current
      ) => {
        const next =
          new Set(
            current
          );

        for (
          const id of
            ids
        ) {
          if (
            allSelected
          ) {
            next.delete(
              id
            );
          } else {
            next.add(
              id
            );
          }
        }

        return next;
      }
    );
  }

  function clearSelection() {
    setSelectedIds(
      new Set()
    );

    setBulkMessage(
      null
    );
  }

  /* =======================================================
     BULK STATE
  ======================================================= */

  const analyzing =
    analysisTask.running;

  const analyzeProgress:
    Progress | null =
    analysisTask.running
      ? {
          current:
            analysisTask.current,

          total:
            analysisTask.total,
        }
      : null;


  const [
    designing,
    setDesigning,
  ] =
    useState(
      false
    );

  const [
    designProgress,
    setDesignProgress,
  ] =
    useState<Progress | null>(
      null
    );

  const [
    drafting,
    setDrafting,
  ] =
    useState(
      false
    );

  const [
    draftProgress,
    setDraftProgress,
  ] =
    useState<Progress | null>(
      null
    );


  const [
    scheduleDialogOpen,
    setScheduleDialogOpen,
  ] =
    useState(
      false
    );

  const [
    cancellingSchedules,
    setCancellingSchedules,
  ] =
    useState(
      false
    );

  const [
    bulkMessage,
    setBulkMessage,
  ] =
    useState<
      string
      | null
    >(
      null
    );

  const [
    deleteDialogOpen,
    setDeleteDialogOpen,
  ] =
    useState(
      false
    );

  const [
    isDeleting,
    startDeleteTransition,
  ] =
    useTransition();

  const busy =
    analyzing ||
    designing ||
    drafting ||
    cancellingSchedules ||
    isDeleting;

  /* =======================================================
     BULK ANALYZE
  ======================================================= */

  function handleBulkAnalyze() {
    if (
      busy ||
      selectedIds.size ===
        0
    ) {
      return;
    }

    const selectedLeads =
      leads.filter(
        (
          lead
        ) =>
          selectedIds.has(
            lead.id
          )
      );

    const started =
      startBulkAnalysis(
        selectedLeads.map(
          (
            lead
          ) => ({
            id:
              lead.id,

            companyName:
              lead.companyName,
          })
        )
      );

    if (
      !started
    ) {
      return;
    }

    setBulkMessage(
      language ===
        "de"
        ? "Analyse läuft im Hintergrund. Du kannst Leadbase weiter benutzen."
        : "Analysis is running in the background. You can keep using Leadbase."
    );

    setSelectedIds(
      new Set()
    );
  }

  async function ensurePublicPreviewAndGif(
    leadId:
      string
  ) {
    const shareResponse =
      await fetch(
        `/api/leads/${encodeURIComponent(
          leadId
        )}/redesign-preview/share`,
        {
          method:
            "POST",

          headers: {
            "Content-Type":
              "application/json",
          },

          body:
            JSON.stringify({}),
        }
      );

    const shareResult =
      (
        await shareResponse.json()
      ) as ShareCreateResponse;

    if (
      !shareResponse.ok ||
      !shareResult.ok ||
      !shareResult.shareUrl
    ) {
      throw new Error(
        shareResult.error ??
        "Could not create customer preview."
      );
    }

    const gifResponse =
      await fetch(
        `/api/leads/${encodeURIComponent(
          leadId
        )}/preview-gif`,
        {
          method:
            "POST",
        }
      );

    const gifResult =
      (
        await gifResponse.json()
      ) as PreviewGifGenerationResponse;

    if (
      !gifResponse.ok ||
      !gifResult.ok ||
      !gifResult.gifUrl
    ) {
      throw new Error(
        gifResult.error ??
        "Could not create preview GIF."
      );
    }
  }

  /* =======================================================
     BULK DESIGN
  ======================================================= */

  async function handleBulkDesign() {
    if (
      busy ||
      selectedIds.size ===
        0
    ) {
      return;
    }

    const selectedLeads =
      leads.filter(
        (
          lead
        ) =>
          selectedIds.has(
            lead.id
          )
      );

    const eligible =
      selectedLeads.filter(
        (
          lead
        ) =>
          lead.analysisStatus ===
            "COMPLETED" &&
          Boolean(
            lead.websiteUrl
          )
      );

    const skippedCount =
      selectedLeads.length -
      eligible.length;

    if (
      eligible.length ===
        0
    ) {
      setBulkMessage(
        ui.noDesignEligible
      );

      return;
    }

    setDesigning(
      true
    );

    setBulkMessage(
      null
    );

    setDesignProgress({
      current:
        0,

      total:
        eligible.length,
    });

    startBulkDesignTask(
      eligible.length,
      eligible[0]?.companyName ?? null
    );

    let createdCount =
      0;

    let existingCount =
      0;

    let failedCount =
      0;

    let gifReadyCount =
      0;

    let gifFailedCount =
      0;

    try {
      for (
        let index =
          0;
        index <
          eligible.length;
        index +=
          1
      ) {
        const lead =
          eligible[
            index
          ];

        updateBulkDesignTask(
          index,
          lead.companyName
        );

        try {
          const response =
            await fetch(
              `/api/leads/${encodeURIComponent(
                lead.id
              )}/redesign-v2`,
              {
                method:
                  "POST",

                headers: {
                  "Content-Type":
                    "application/json",
                },

                body:
                  JSON.stringify({
                    regenerate:
                      false,
                  }),
              }
            );

          const result =
            (
              await response.json()
            ) as
              DesignResponse;

          if (
            !response.ok ||
            result.ok ===
              false
          ) {
            failedCount +=
              1;

            console.error(
              `Design generation failed for ${lead.companyName}:`,
              result.error
            );
          } else if (
            result.generated ===
              false
          ) {
            existingCount +=
              1;
          } else {
            createdCount +=
              1;
          }

          try {
            await ensurePublicPreviewAndGif(
              lead.id
            );

            gifReadyCount +=
              1;
          } catch (
            gifError
          ) {
            gifFailedCount +=
              1;

            console.error(
              `Preview/GIF preparation failed for ${lead.companyName}:`,
              gifError
            );
          }
        } catch (
          error
        ) {
          failedCount +=
            1;

          console.error(
            `Design generation failed for ${lead.companyName}:`,
            error
          );
        }

        setDesignProgress({
          current:
            index +
            1,

          total:
            eligible.length,
        });


        updateBulkDesignTask(
          index + 1,
          eligible[index + 1]?.companyName ?? null
        );
      }

      const parts =
        [
          `${createdCount} ${ui.created}`,

          existingCount >
            0
            ? `${existingCount} ${ui.existing}`
            : null,

          skippedCount >
            0
            ? `${skippedCount} ${ui.skipped}`
            : null,

          failedCount >
            0
            ? `${failedCount} ${ui.failed}`
            : null,

          gifReadyCount >
            0
            ? language ===
                "de"
              ? `${gifReadyCount} GIF bereit`
              : `${gifReadyCount} GIF ready`
            : null,

          gifFailedCount >
            0
            ? language ===
                "de"
              ? `${gifFailedCount} GIF fehlgeschlagen`
              : `${gifFailedCount} GIF failed`
            : null,
        ].filter(
          Boolean
        );

      setBulkMessage(
        `${ui.designsFinished}: ${parts.join(
          " · "
        )}`
      );

      notify({
        variant:
          failedCount >
            0 ||
          gifFailedCount >
            0
            ? "warning"
            : "success",

        title:
          language ===
            "de"
            ? "Design-Generierung abgeschlossen"
            : "Design generation complete",

        description:
          language ===
            "de"
            ? `${createdCount} erstellt · ${existingCount} vorhanden · ${gifReadyCount} GIF bereit · ${gifFailedCount} GIF fehlgeschlagen`
            : `${createdCount} created · ${existingCount} existing · ${gifReadyCount} GIF ready · ${gifFailedCount} GIF failed`,
      });

      setSelectedIds(
        new Set()
      );

      router.refresh();
    } finally {
      finishBulkDesignTask();

      setDesigning(
        false
      );

      setDesignProgress(
        null
      );
    }
  }

  /* =======================================================
     BULK OUTREACH DRAFTS
  ======================================================= */

  async function handleBulkDrafts() {
    if (
      busy ||
      selectedIds.size ===
        0
    ) {
      return;
    }

    const ids =
      Array.from(
        selectedIds
      );

    setDrafting(
      true
    );

    setBulkMessage(
      null
    );

    setDraftProgress({
      current:
        0,

      total:
        ids.length,
    });

    let createdCount =
      0;

    let skippedCount =
      0;

    let failedCount =
      0;

    try {
      for (
        let index =
          0;
        index <
          ids.length;
        index +=
          1
      ) {
        const leadId =
          ids[
            index
          ];

        try {
          const result =
            await generateLeadOutreachDraftForBulk(
              leadId
            );

          if (
            !result.success
          ) {
            failedCount +=
              1;
          } else if (
            result.status ===
              "created"
          ) {
            createdCount +=
              1;
          } else {
            skippedCount +=
              1;
          }
        } catch (
          error
        ) {
          console.error(
            `Bulk draft generation failed for ${leadId}:`,
            error
          );

          failedCount +=
            1;
        }

        setDraftProgress({
          current:
            index +
            1,

          total:
            ids.length,
        });
      }

      const parts =
        [
          `${createdCount} Drafts erstellt`,

          skippedCount >
            0
            ? `${skippedCount} übersprungen`
            : null,

          failedCount >
            0
            ? `${failedCount} fehlgeschlagen`
            : null,
        ].filter(
          Boolean
        );

      setBulkMessage(
        parts.join(
          " · "
        )
      );

      notify({
        variant:
          failedCount >
          0
            ? "warning"
            : "success",

        title:
          language ===
            "de"
            ? "Draft-Generierung abgeschlossen"
            : "Draft generation complete",

        description:
          language ===
            "de"
            ? `${createdCount} erstellt · ${skippedCount} übersprungen · ${failedCount} fehlgeschlagen`
            : `${createdCount} created · ${skippedCount} skipped · ${failedCount} failed`,
      });

      setSelectedIds(
        new Set()
      );

      router.refresh();
    } finally {
      setDrafting(
        false
      );

      setDraftProgress(
        null
      );
    }
  }

  /* =======================================================
     BULK SCHEDULE OUTREACH
  ======================================================= */

  async function handleBulkCancelScheduledOutreach() {
    if (
      busy ||
      selectedIds.size ===
        0
    ) {
      return;
    }

    const ids =
      Array.from(
        selectedIds
      );

    setCancellingSchedules(
      true
    );

    setBulkMessage(
      null
    );

    let cancelledCount =
      0;

    let failedCount =
      0;

    try {
      for (
        const leadId of
          ids
      ) {
        try {
          const result =
            await cancelScheduledOutreachForBulk(
              leadId
            );

          if (
            !result.success
          ) {
            failedCount +=
              1;
          } else {
            cancelledCount +=
              result.cancelled;
          }
        } catch (
          error
        ) {
          failedCount +=
            1;

          console.error(
            `Could not cancel scheduled outreach for ${leadId}:`,
            error
          );
        }
      }

      setBulkMessage(
        language ===
          "de"
          ? `${cancelledCount} geplante Sendungen gestoppt${
              failedCount >
                0
                ? ` · ${failedCount} fehlgeschlagen`
                : ""
            }`
          : `${cancelledCount} scheduled sends cancelled${
              failedCount >
                0
                ? ` · ${failedCount} failed`
                : ""
            }`
      );

      setSelectedIds(
        new Set()
      );

      router.refresh();
    } finally {
      setCancellingSchedules(
        false
      );
    }
  }

  /* =======================================================
     BULK DELETE
  ======================================================= */

  function handleBulkDelete() {
    if (
      busy ||
      selectedIds.size ===
        0
    ) {
      return;
    }

    const ids =
      Array.from(
        selectedIds
      );

    startDeleteTransition(
      async () => {
        try {
          const result =
            await bulkDeleteLeads(
              ids
            );

          if (
            !result.success
          ) {
            setBulkMessage(
              result.error
            );

            return;
          }

          setSelectedIds(
            new Set()
          );

          setDeleteDialogOpen(
            false
          );

          setBulkMessage(
            result.deletedCount ===
              1
              ? text.table
                  .deletedOne
              : text.table.deletedMany.replace(
                  "{count}",
                  String(
                    result.deletedCount
                  )
                )
          );

          router.refresh();
        } catch (
          error
        ) {
          console.error(
            "Bulk delete failed:",
            error
          );

          setBulkMessage(
            text.table
              .deleteFailed
          );
        }
      }
    );
  }

  /* =======================================================
     LEAD ACTION MENU
  ======================================================= */

  function LeadActions({
    lead,
  }: {
    lead:
      LeadTableRow;
  }) {
    return (
      <DropdownMenu>
        <DropdownMenuTrigger
          render={
            <Button
              variant="ghost"
              size="icon"
              aria-label={`Actions for ${lead.companyName}`}
              className="size-8"
            />
          }
        >
          <MoreHorizontal className="size-4" />
        </DropdownMenuTrigger>

        <DropdownMenuContent align="end">
          <DropdownMenuItem
            onClick={() =>
              router.push(
                `/leads/${lead.id}`
              )
            }
          >
            <Eye className="size-4" />

            {
              text.common
                .openLead
            }
          </DropdownMenuItem>

          <DropdownMenuItem
            onClick={() =>
              router.push(
                `/leads/${lead.id}/edit`
              )
            }
          >
            <Pencil className="size-4" />

            {
              text.common
                .editLead
            }
          </DropdownMenuItem>

          {lead.websiteUrl ? (
            <>
              <DropdownMenuSeparator />

              <DropdownMenuItem
                onClick={() =>
                  window.open(
                    normalizeUrl(
                      lead.websiteUrl!
                    ),
                    "_blank",
                    "noopener,noreferrer"
                  )
                }
              >
                <ExternalLink className="size-4" />

                {
                  text.common
                    .visitWebsite
                }
              </DropdownMenuItem>
            </>
          ) : null}
        </DropdownMenuContent>
      </DropdownMenu>
    );
  }

  /* =======================================================
     RENDER
  ======================================================= */

  return (
    <>
      {/* ===================================================
          CONTROLS
      =================================================== */}

      <div className="mt-6 flex flex-col gap-3 md:mt-8 lg:flex-row lg:items-center lg:justify-between">
        <div className="relative w-full sm:max-w-sm">
          <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />

          <Input
            value={
              search
            }
            onChange={(
              event
            ) =>
              setSearch(
                event.target
                  .value
              )
            }
            placeholder={
              text.table
                .searchPlaceholder
            }
            className="pl-9"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* VIEW MODE */}

          <div className="inline-flex rounded-lg border bg-background p-1">
            <button
              type="button"
              onClick={() =>
                changeView(
                  "compact"
                )
              }
              className={`inline-flex h-8 items-center gap-1.5 rounded-md px-2.5 text-xs font-medium transition-colors ${
                viewMode ===
                "compact"
                  ? "bg-muted text-foreground"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <LayoutList className="size-3.5" />

              {
                ui.compact
              }
            </button>

            <button
              type="button"
              onClick={() =>
                changeView(
                  "table"
                )
              }
              className={`inline-flex h-8 items-center gap-1.5 rounded-md px-2.5 text-xs font-medium transition-colors ${
                viewMode ===
                "table"
                  ? "bg-muted text-foreground"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <Table2 className="size-3.5" />

              {
                ui.table
              }
            </button>
          </div>

          {viewMode === "compact" ? (
            <div
              className={`inline-flex h-9 items-center gap-2 rounded-lg border px-3 text-xs font-medium ${
                hasActiveFilters
                  ? "bg-muted/30 text-muted-foreground"
                  : "border-primary/15 bg-primary/[0.045] text-primary"
              }`}
              title={
                hasActiveFilters
                  ? language === "de"
                    ? "Filter zurücksetzen, um manuell zu sortieren"
                    : "Reset filters to reorder manually"
                  : language === "de"
                    ? "Gruppen und Leads per Drag-and-Drop sortieren"
                    : "Drag and drop groups and leads to reorder"
              }
            >
              <GripVertical className="size-3.5" />

              {hasActiveFilters
                ? language === "de"
                  ? "Sortierung pausiert"
                  : "Sorting paused"
                : language === "de"
                  ? "Direkt sortieren"
                  : "Instant ordering"}
            </div>
          ) : null}

          <Link
            href="/scheduled"
            className="inline-flex h-9 items-center gap-2 rounded-lg border bg-background px-3 text-sm font-medium transition-colors hover:bg-muted/50"
          >
            <CalendarClock className="size-4" />

            {language ===
              "de"
              ? "Geplante Mails"
              : "Scheduled emails"}
          </Link>

          <button
            type="button"
            onClick={() =>
              setFiltersOpen(
                (
                  current
                ) =>
                  !current
              )
            }
            className="inline-flex h-9 items-center gap-2 rounded-lg border bg-background px-3 text-sm font-medium hover:bg-muted/50"
          >
            <SlidersHorizontal className="size-4" />

            {
              text.table
                .filters
            }
          </button>

          {hasActiveFilters ? (
            <Button
              type="button"
              variant="ghost"
              onClick={
                resetFilters
              }
            >
              {
                text.table
                  .reset
              }
            </Button>
          ) : null}
        </div>
      </div>

      {/* ===================================================
          FILTER PANEL
      =================================================== */}

      {filtersOpen ? (
        <div className="mt-3 grid gap-3 rounded-xl border bg-muted/20 p-4 sm:grid-cols-2">
          <div className="space-y-1.5">
            <p className="text-xs font-medium text-muted-foreground">
              {
                text.common
                  .status
              }
            </p>

            <select
              value={
                status
              }
              onChange={(
                event
              ) =>
                setStatus(
                  event.target
                    .value
                )
              }
              className="h-10 w-full rounded-lg border bg-background px-3 text-sm"
            >
              <option value="ALL">
                {
                  text.table
                    .allStatuses
                }
              </option>

              {[
                "NEW",
                "RESEARCHING",
                "QUALIFIED",
                "NOT_A_FIT",
                "DRAFT_READY",
                "CONTACTED",
                "REPLIED",
                "CALL_BOOKED",
                "PROPOSAL",
                "WON",
                "LOST",
                "DO_NOT_CONTACT",
              ].map(
                (
                  item
                ) => (
                  <option
                    key={
                      item
                    }
                    value={
                      item
                    }
                  >
                    {getLeadStatusLabel(
                      item,
                      language
                    )}
                  </option>
                )
              )}
            </select>
          </div>

          <div className="space-y-1.5">
            <p className="text-xs font-medium text-muted-foreground">
              {
                text.common
                  .priority
              }
            </p>

            <select
              value={
                priority
              }
              onChange={(
                event
              ) =>
                setPriority(
                  event.target
                    .value
                )
              }
              className="h-10 w-full rounded-lg border bg-background px-3 text-sm"
            >
              <option value="ALL">
                {
                  text.table
                    .allPriorities
                }
              </option>

              <option value="HIGH">
                {
                  text.common
                    .priorityHigh
                }
              </option>

              <option value="MEDIUM">
                {
                  text.common
                    .priorityMedium
                }
              </option>

              <option value="LOW">
                {
                  text.common
                    .priorityLow
                }
              </option>

              <option value="NONE">
                {
                  text.common
                    .noPriority
                }
              </option>
            </select>
          </div>
        </div>
      ) : null}

      {/* ===================================================
          BULK BAR
      =================================================== */}

      {selectedIds.size >
      0 ? (
        <div className="mt-4 flex flex-col gap-3 rounded-xl border bg-muted/30 p-3 lg:flex-row lg:items-center lg:justify-between">
          <div className="flex items-center gap-3">
            <div className="flex size-8 items-center justify-center rounded-lg border bg-background text-xs font-semibold">
              {
                selectedIds.size
              }
            </div>

            <div>
              <p className="text-sm font-medium">
                {selectedIds.size ===
                1
                  ? text.table
                      .selectedOne
                  : text.table.selectedMany.replace(
                      "{count}",
                      String(
                        selectedIds.size
                      )
                    )}
              </p>

              <p className="text-xs text-muted-foreground">
                {
                  text.table
                    .chooseAction
                }
              </p>
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            <Button
              type="button"
              variant="ghost"
              disabled={
                busy
              }
              onClick={
                clearSelection
              }
              className="gap-2"
            >
              <X className="size-4" />

              {
                text.table
                  .clear
              }
            </Button>

            <Button
              type="button"
              variant="outline"
              disabled={
                busy
              }
              onClick={
                handleBulkAnalyze
              }
              className="gap-2"
            >
              {analyzing ? (
                <>
                  <Loader2 className="size-4 animate-spin" />

                  {analyzeProgress
                    ? `${analyzeProgress.current}/${analyzeProgress.total}`
                    : text.table
                        .analyzing}
                </>
              ) : (
                <>
                  <Sparkles className="size-4" />

                  {
                    text.table
                      .analyzeSelected
                  }
                </>
              )}
            </Button>

            <Button
              type="button"
              variant="outline"
              disabled={
                busy
              }
              onClick={
                handleBulkDesign
              }
              className="gap-2"
            >
              {designing ? (
                <>
                  <Loader2 className="size-4 animate-spin" />

                  {designProgress
                    ? `${designProgress.current}/${designProgress.total}`
                    : ui.generating}
                </>
              ) : (
                <>
                  <WandSparkles className="size-4" />

                  {
                    ui.generateDesigns
                  }
                </>
              )}
            </Button>

            <Button
              type="button"
              variant="outline"
              disabled={
                busy
              }
              onClick={
                handleBulkDrafts
              }
              className="gap-2"
            >
              {drafting ? (
                <>
                  <Loader2 className="size-4 animate-spin" />

                  {draftProgress
                    ? `${draftProgress.current}/${draftProgress.total}`
                    : "Drafts werden erstellt"}
                </>
              ) : (
                <>
                  <MailPlus className="size-4" />

                  Drafts erstellen
                </>
              )}
            </Button>

            <div className="flex flex-wrap items-center gap-2 rounded-lg border bg-background p-1.5">
              <Button
                type="button"
                size="sm"
                variant="secondary"
                disabled={
                  busy
                }
                onClick={() =>
                  setScheduleDialogOpen(
                    true
                  )
                }
                className="gap-2"
              >
                <CalendarClock className="size-4" />

                {language ===
                  "de"
                  ? "Später senden"
                  : "Send later"}
              </Button>

              <Button
                type="button"
                size="sm"
                variant="ghost"
                disabled={
                  busy
                }
                onClick={
                  handleBulkCancelScheduledOutreach
                }
                className="gap-2"
                title={
                  language ===
                    "de"
                    ? "Geplanten Outreach für die Auswahl stoppen"
                    : "Cancel scheduled outreach for selection"
                }
              >
                {cancellingSchedules ? (
                  <Loader2 className="size-4 animate-spin" />
                ) : (
                  <CalendarX2 className="size-4" />
                )}

                {language ===
                  "de"
                  ? "Versand stoppen"
                  : "Cancel send"}
              </Button>
            </div>

            <Button
              type="button"
              variant="destructive"
              disabled={
                busy
              }
              onClick={() =>
                setDeleteDialogOpen(
                  true
                )
              }
              className="gap-2"
            >
              {isDeleting ? (
                <Loader2 className="size-4 animate-spin" />
              ) : (
                <Trash2 className="size-4" />
              )}

              {
                text.table
                  .deleteSelected
              }
            </Button>
          </div>
        </div>
      ) : null}

      {bulkMessage ? (
        <div className="mt-3 rounded-lg border bg-muted/20 px-3 py-2.5 text-sm text-muted-foreground">
          {
            bulkMessage
          }
        </div>
      ) : null}




      {/* ===================================================
          SELECT ALL
      =================================================== */}

      {filteredLeads.length >
      0 ? (
        <div className="mt-4 flex items-center gap-3 px-1 text-xs text-muted-foreground">
          <SelectionCheckbox
            checked={
              allVisibleSelected
            }
            indeterminate={
              someVisibleSelected
            }
            disabled={
              busy
            }
            label={
              text.table
                .selectAllVisible
            }
            onChange={
              toggleAllVisible
            }
          />

          <span>
            {
              filteredLeads.length
            }{" "}
            {
              ui.leads
            }
          </span>
        </div>
      ) : null}

      {/* ===================================================
          COMPACT VIEW
      =================================================== */}

      {viewMode ===
      "compact" ? (
        <div className="mt-3 space-y-3">
          {groups.map(
            (
              group
            ) => {
              const collapsed =
                collapsedGroups.has(
                  group.key
                );

              const groupSelectedCount =
                group.leads.filter(
                  (
                    lead
                  ) =>
                    selectedIds.has(
                      lead.id
                    )
                ).length;

              const allGroupSelected =
                group.leads.length >
                  0 &&
                groupSelectedCount ===
                  group.leads.length;

              const someGroupSelected =
                groupSelectedCount >
                  0 &&
                !allGroupSelected;

              return (
                <div
                  key={
                    group.key
                  }
                  className={`relative overflow-visible rounded-2xl border bg-card shadow-[0_1px_2px_rgba(15,23,42,0.025)] transition-[border-color,box-shadow,transform] ${
                    draggedGroupKey === group.key
                      ? "border-primary/35 shadow-[0_10px_32px_rgba(0,43,186,0.10)]"
                      : "hover:border-border/80 hover:shadow-[0_8px_28px_rgba(15,23,42,0.045)]"
                  }`}
                >
                  {groupDropTarget?.targetKey === group.key &&
                  draggedGroupKey !== group.key ? (
                    <div
                      className={`pointer-events-none absolute left-3 right-3 z-20 h-0.5 rounded-full bg-primary shadow-[0_0_0_1px_rgba(255,255,255,0.6),0_0_10px_rgba(77,107,255,0.35)] ${
                        groupDropTarget.placeAfter
                          ? "-bottom-[7px]"
                          : "-top-[7px]"
                      }`}
                    >
                      <span className="absolute -left-1 top-1/2 size-2.5 -translate-y-1/2 rounded-full border-2 border-background bg-primary" />
                    </div>
                  ) : null}
                  {/* CAMPAIGN HEADER */}

                  <div
                    onDragOver={(event) => {
                      if (
                        draggedGroupKey &&
                        manualSortingEnabled
                      ) {
                        event.preventDefault();
                        event.stopPropagation();

                        const bounds =
                          event.currentTarget.getBoundingClientRect();

                        setGroupDropTarget({
                          targetKey: group.key,
                          placeAfter:
                            event.clientY >
                            bounds.top + bounds.height / 2,
                        });
                      }
                    }}
                    onDrop={(event) => {
                      if (!draggedGroupKey) {
                        return;
                      }

                      event.preventDefault();
                      event.stopPropagation();

                      const target =
                        groupDropTarget?.targetKey === group.key
                          ? groupDropTarget
                          : {
                              targetKey: group.key,
                              placeAfter: false,
                            };

                      moveGroupRelative(
                        draggedGroupKey,
                        group.key,
                        target.placeAfter
                      );

                      setDraggedGroupKey(null);
                      setGroupDropTarget(null);
                    }}
                    className={`flex items-center gap-2.5 bg-gradient-to-r from-muted/35 via-muted/15 to-transparent px-3 py-3 sm:px-4 ${
                      collapsed
                        ? "rounded-2xl"
                        : "rounded-t-2xl border-b"
                    }`}
                  >
                    <button
                      type="button"
                      draggable={
                        manualSortingEnabled
                      }
                      onDragStart={(event) => {
                        if (!manualSortingEnabled) {
                          event.preventDefault();
                          return;
                        }

                        setDraggedGroupKey(
                          group.key
                        );
                        event.dataTransfer.effectAllowed =
                          "move";
                        event.dataTransfer.setData(
                          "text/plain",
                          `group:${group.key}`
                        );
                      }}
                      onDragEnd={() => {
                        setDraggedGroupKey(null);
                        setGroupDropTarget(null);
                      }}
                      className={`flex size-7 shrink-0 items-center justify-center rounded-md text-muted-foreground transition-colors ${
                        manualSortingEnabled
                          ? "cursor-grab hover:bg-primary/10 hover:text-primary active:cursor-grabbing"
                          : "cursor-not-allowed opacity-35"
                      }`}
                      aria-label={
                        language === "de"
                          ? `${group.name} verschieben`
                          : `Move ${group.name}`
                      }
                      title={
                        hasActiveFilters
                          ? language === "de"
                            ? "Filter zurücksetzen, um zu sortieren"
                            : "Reset filters to sort"
                          : language === "de"
                            ? "Gruppe ziehen"
                            : "Drag group"
                      }
                    >
                      <GripVertical className="size-4" />
                    </button>

                    <SelectionCheckbox
                      checked={
                        allGroupSelected
                      }
                      indeterminate={
                        someGroupSelected
                      }
                      disabled={
                        busy
                      }
                      label={`Select ${group.name}`}
                      onChange={() =>
                        toggleCampaignSelection(
                          group.leads
                        )
                      }
                    />

                    <button
                      type="button"
                      onClick={() =>
                        toggleGroupOpen(
                          group.key
                        )
                      }
                      className="flex min-w-0 flex-1 items-center gap-2 text-left"
                    >
                      {collapsed ? (
                        <Folder className="size-4 shrink-0 text-muted-foreground" />
                      ) : (
                        <FolderOpen className="size-4 shrink-0 text-muted-foreground" />
                      )}

                      <span className="truncate text-sm font-semibold">
                        {
                          group.name
                        }
                      </span>

                      <span className="shrink-0 rounded-md border bg-background px-1.5 py-0.5 text-[10px] font-medium text-muted-foreground">
                        {
                          group.leads.length
                        }
                      </span>

                      <span className="ml-auto">
                        {collapsed ? (
                          <ChevronRight className="size-4 text-muted-foreground" />
                        ) : (
                          <ChevronDown className="size-4 text-muted-foreground" />
                        )}
                      </span>
                    </button>
                  </div>

                  {!collapsed ? (
                    <div className="divide-y">
                      {group.leads.map(
                        (
                          lead
                        ) => {
                          const selected =
                            selectedIds.has(
                              lead.id
                            );

                          const analyzed =
                            lead.analysisStatus ===
                            "COMPLETED";

                          return (
                            <div
                              key={
                                lead.id
                              }
                              onDragOver={(event) => {
                                if (
                                  draggedLeadId &&
                                  manualSortingEnabled
                                ) {
                                  event.preventDefault();
                                  event.stopPropagation();

                                  const bounds =
                                    event.currentTarget.getBoundingClientRect();

                                  setLeadDropTarget({
                                    groupKey: group.key,
                                    targetId: lead.id,
                                    placeAfter:
                                      event.clientY >
                                      bounds.top + bounds.height / 2,
                                  });
                                }
                              }}
                              onDrop={(event) => {
                                if (!draggedLeadId) {
                                  return;
                                }

                                event.preventDefault();
                                event.stopPropagation();

                                const target =
                                  leadDropTarget?.targetId === lead.id
                                    ? leadDropTarget
                                    : {
                                        groupKey: group.key,
                                        targetId: lead.id,
                                        placeAfter: false,
                                      };

                                moveLeadRelative(
                                  group.key,
                                  draggedLeadId,
                                  lead.id,
                                  target.placeAfter
                                );

                                setDraggedLeadId(null);
                                setLeadDropTarget(null);
                              }}
                              className={`group/lead relative flex flex-col gap-3 px-3 py-3.5 transition-[background-color,box-shadow] sm:px-4 lg:flex-row lg:items-center ${
                                selected
                                  ? "bg-primary/[0.045]"
                                  : "hover:bg-muted/20"
                              } ${
                                draggedLeadId === lead.id
                                  ? "bg-primary/[0.06] opacity-70"
                                  : ""
                              }`}
                            >
                              {leadDropTarget?.groupKey === group.key &&
                              leadDropTarget.targetId === lead.id &&
                              draggedLeadId !== lead.id ? (
                                <div
                                  className={`pointer-events-none absolute left-3 right-3 z-20 h-0.5 rounded-full bg-primary shadow-[0_0_0_1px_rgba(255,255,255,0.55),0_0_10px_rgba(77,107,255,0.32)] ${
                                    leadDropTarget.placeAfter
                                      ? "-bottom-px"
                                      : "-top-px"
                                  }`}
                                >
                                  <span className="absolute -left-1 top-1/2 size-2.5 -translate-y-1/2 rounded-full border-2 border-background bg-primary" />
                                </div>
                              ) : null}

                              <div className="flex min-w-0 items-start gap-2.5 lg:flex-[1.4]">
                                <button
                                  type="button"
                                  draggable={
                                    manualSortingEnabled
                                  }
                                  onDragStart={(event) => {
                                    if (!manualSortingEnabled) {
                                      event.preventDefault();
                                      return;
                                    }

                                    setDraggedLeadId(
                                      lead.id
                                    );
                                    event.dataTransfer.effectAllowed =
                                      "move";
                                    event.dataTransfer.setData(
                                      "text/plain",
                                      `lead:${lead.id}`
                                    );
                                  }}
                                  onDragEnd={() => {
                                    setDraggedLeadId(null);
                                    setLeadDropTarget(null);
                                  }}
                                  className={`mt-0.5 flex size-7 shrink-0 items-center justify-center rounded-md text-muted-foreground/70 transition-all ${
                                    manualSortingEnabled
                                      ? "cursor-grab opacity-45 hover:bg-primary/10 hover:text-primary hover:opacity-100 active:cursor-grabbing group-hover/lead:opacity-100"
                                      : "cursor-not-allowed opacity-20"
                                  }`}
                                  aria-label={
                                    language === "de"
                                      ? `${lead.companyName} verschieben`
                                      : `Move ${lead.companyName}`
                                  }
                                  title={
                                    hasActiveFilters
                                      ? language === "de"
                                        ? "Filter zurücksetzen, um zu sortieren"
                                        : "Reset filters to sort"
                                      : language === "de"
                                        ? "Lead ziehen"
                                        : "Drag lead"
                                  }
                                >
                                  <GripVertical className="size-4" />
                                </button>

                                <div className="pt-1">
                                  <SelectionCheckbox
                                    checked={
                                      selected
                                    }
                                    disabled={
                                      busy
                                    }
                                    label={`Select ${lead.companyName}`}
                                    onChange={() =>
                                      toggleLead(
                                        lead.id
                                      )
                                    }
                                  />
                                </div>

                                <Link
  href={`/leads/${lead.id}`}
  className="min-w-0 text-left"
>
  <div className="flex min-w-0 items-center gap-2">
    <p className="min-w-0 truncate text-sm font-semibold hover:underline">
      {
        lead.companyName
      }
    </p>

    {hotLeadSummaries[
      lead.id
    ] ? (
      <LeadHotScoreIndicator
        summary={
          hotLeadSummaries[
            lead.id
          ]
        }
      />
    ) : null}
  </div>

  <div className="mt-1 flex min-w-0 flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-muted-foreground">
    {lead.location ? (
      <span className="inline-flex min-w-0 items-center gap-1">
        <MapPin className="size-3 shrink-0" />

        <span className="truncate">
          {
            lead.location
          }
        </span>
      </span>
    ) : null}

    {lead.industry ? (
      <span className="truncate">
        {
          lead.industry
        }
      </span>
    ) : null}
  </div>
</Link>
                              </div>

                              {/* SCORES */}

                              <div className="flex shrink-0 items-center gap-4 lg:w-[150px]">
                                <div>
                                  <p className="text-[9px] uppercase tracking-wide text-muted-foreground">
                                    Web
                                  </p>

                                  <p className="text-sm font-semibold">
                                    {lead.websiteScore ??
                                      "—"}
                                  </p>
                                </div>

                                <div>
                                  <p className="text-[9px] uppercase tracking-wide text-muted-foreground">
                                    Opp.
                                  </p>

                                  <p className="text-sm font-semibold">
                                    {lead.opportunityScore ??
                                      "—"}
                                  </p>
                                </div>
                              </div>

                              {/* ANALYSIS */}

                              <div className="shrink-0 lg:w-[115px]">
                                <div
                                  className={`inline-flex items-center gap-1.5 text-[11px] font-medium ${
                                    analyzed
                                      ? "text-emerald-600 dark:text-emerald-400"
                                      : "text-muted-foreground"
                                  }`}
                                >
                                  <span
                                    className={`size-1.5 rounded-full ${
                                      analyzed
                                        ? "bg-emerald-500"
                                        : "bg-muted-foreground/40"
                                    }`}
                                  />

                                  {analyzed
                                    ? ui.analyzed
                                    : ui.notAnalyzed}
                                </div>
                              </div>

                              {/* STATUS */}

                              <div className="shrink-0 lg:w-[125px]">
                                <Badge
                                  variant="outline"
                                  className={`whitespace-nowrap text-[10px] ${statusClass(
                                    lead.status
                                  )}`}
                                >
                                  {getLeadStatusLabel(
                                    lead.status,
                                    language
                                  )}
                                </Badge>
                              </div>

                              {/* PRIORITY */}

                              <div className="shrink-0 lg:w-[80px]">
                                <span
                                  className={`text-[11px] font-medium ${priorityClass(
                                    lead.priority
                                  )}`}
                                >
                                  {getLeadPriorityLabel(
                                    lead.priority,
                                    language
                                  )}
                                </span>
                              </div>

                              {/* CONTACT */}

                              <div className="min-w-0 lg:w-[180px]">
                                {lead.contactEmail ? (
                                  <div className="flex items-center gap-1.5">
                                    <Mail className="size-3 shrink-0 text-muted-foreground" />

                                    <span className="truncate text-[11px] text-muted-foreground">
                                      {
                                        lead.contactEmail
                                      }
                                    </span>
                                  </div>
                                ) : (
                                  <span className="text-[11px] text-muted-foreground">
                                    {lead.contactFormUrl
                                      ? text.common
                                          .contactForm
                                      : text.common
                                          .noEmailFound}
                                  </span>
                                )}
                              </div>

                              {/* CUSTOMER PREVIEW VIEWS */}

                              <div className="flex shrink-0 justify-start lg:w-[92px]">
                                {previewSummaries[
                                  lead.id
                                ] ? (
                                  <LeadPreviewVisitsButton
                                    summary={
                                      previewSummaries[
                                        lead.id
                                      ]
                                    }
                                  />
                                ) : null}
                              </div>

                              {/* DATE */}

                              <div className="shrink-0 lg:w-[70px]">
                                <span className="text-[11px] text-muted-foreground">
                                  {formatDate(
                                    lead.lastContactedAt,
                                    language
                                  )}
                                </span>
                              </div>

                              <div className="ml-auto shrink-0">
                                <LeadActions
                                  lead={
                                    lead
                                  }
                                />
                              </div>
                            </div>
                          );
                        }
                      )}
                    </div>
                  ) : null}
                </div>
              );
            }
          )}

          {filteredLeads.length ===
          0 ? (
            <div className="rounded-xl border bg-background px-5 py-12 text-center">
              <p className="text-sm font-medium">
                {
                  text.table
                    .noMatching
                }
              </p>

              <p className="mt-1 text-sm text-muted-foreground">
                {
                  text.table
                    .noMatchingDescription
                }
              </p>

              {hasActiveFilters ? (
                <Button
                  type="button"
                  variant="outline"
                  className="mt-4"
                  onClick={
                    resetFilters
                  }
                >
                  {
                    text.table
                      .clearFilters
                  }
                </Button>
              ) : null}
            </div>
          ) : null}
        </div>
      ) : null}

      {/* ===================================================
          TABLE VIEW
      =================================================== */}

      {viewMode ===
      "table" ? (
        <div className="mt-3 overflow-x-auto rounded-xl border bg-background">
          <Table>
            <TableHeader>
              <TableRow className="hover:bg-transparent">
                <TableHead className="w-12">
                  <SelectionCheckbox
                    checked={
                      allVisibleSelected
                    }
                    indeterminate={
                      someVisibleSelected
                    }
                    disabled={
                      busy
                    }
                    label={
                      text.table
                        .selectAllVisible
                    }
                    onChange={
                      toggleAllVisible
                    }
                  />
                </TableHead>

                <TableHead>
                  {
                    text.common
                      .company
                  }
                </TableHead>

                <TableHead>
                  {
                    ui.campaign
                  }
                </TableHead>

                <TableHead>
                  {
                    ui.scores
                  }
                </TableHead>

                <TableHead>
                  {
                    text.common
                      .status
                  }
                </TableHead>

                <TableHead>
                  {
                    text.common
                      .priority
                  }
                </TableHead>

                <TableHead>
                  {
                    ui.contact
                  }
                </TableHead>

                <TableHead>
                  {
                    ui.previewViews
                  }
                </TableHead>

                <TableHead className="w-12" />
              </TableRow>
            </TableHeader>

            <TableBody>
              {filteredLeads.map(
                (
                  lead
                ) => (
                  <TableRow
                    key={
                      lead.id
                    }
                    className={
                      selectedIds.has(
                        lead.id
                      )
                        ? "bg-muted/30"
                        : undefined
                    }
                  >
                    <TableCell>
                      <SelectionCheckbox
                        checked={
                          selectedIds.has(
                            lead.id
                          )
                        }
                        disabled={
                          busy
                        }
                        label={`Select ${lead.companyName}`}
                        onChange={() =>
                          toggleLead(
                            lead.id
                          )
                        }
                      />
                    </TableCell>

                    <TableCell>
                      <div className="flex min-w-0 items-center gap-2">
                        <Link
                          href={`/leads/${lead.id}`}
                          className="min-w-0 truncate text-left font-medium hover:underline"
                        >
                          {
                            lead.companyName
                          }
                        </Link>

                        {hotLeadSummaries[
                          lead.id
                        ] ? (
                          <LeadHotScoreIndicator
                            summary={
                              hotLeadSummaries[
                                lead.id
                              ]
                            }
                            />
                        ) : null}
                      </div>

                      <p className="mt-0.5 max-w-[260px] truncate text-xs text-muted-foreground">
                        {lead.location ??
                          "—"}
                      </p>
                    </TableCell>

                    <TableCell className="text-xs text-muted-foreground">
                      {lead.campaignName ??
                        ui.uncategorized}
                    </TableCell>

                    <TableCell className="whitespace-nowrap text-xs">
                      <span className="font-semibold">
                        {lead.websiteScore ??
                          "—"}
                      </span>

                      <span className="mx-1.5 text-muted-foreground">
                        /
                      </span>

                      <span className="font-semibold">
                        {lead.opportunityScore ??
                          "—"}
                      </span>
                    </TableCell>

                    <TableCell>
                      <Badge
                        variant="outline"
                        className={`whitespace-nowrap text-[10px] ${statusClass(
                          lead.status
                        )}`}
                      >
                        {getLeadStatusLabel(
                          lead.status,
                          language
                        )}
                      </Badge>
                    </TableCell>

                    <TableCell>
                      <span
                        className={`text-xs font-medium ${priorityClass(
                          lead.priority
                        )}`}
                      >
                        {getLeadPriorityLabel(
                          lead.priority,
                          language
                        )}
                      </span>
                    </TableCell>

                    <TableCell className="max-w-[220px] truncate text-xs text-muted-foreground">
                      {lead.contactEmail ??
                        (
                          lead.contactFormUrl
                            ? text.common
                                .contactForm
                            : text.common
                                .noEmailFound
                        )}
                    </TableCell>

                    <TableCell className="whitespace-nowrap">
                      {previewSummaries[
                        lead.id
                      ] ? (
                        <LeadPreviewVisitsButton
                          summary={
                            previewSummaries[
                              lead.id
                            ]
                          }
                        />
                      ) : (
                        <span className="text-xs text-muted-foreground">
                          —
                        </span>
                      )}
                    </TableCell>

                    <TableCell>
                      <LeadActions
                        lead={
                          lead
                        }
                      />
                    </TableCell>
                  </TableRow>
                )
              )}

              {filteredLeads.length ===
              0 ? (
                <TableRow>
                  <TableCell
                    colSpan={
                      9
                    }
                    className="h-40 text-center text-sm text-muted-foreground"
                  >
                    {
                      text.table
                        .noMatching
                    }
                  </TableCell>
                </TableRow>
              ) : null}
            </TableBody>
          </Table>
        </div>
      ) : null}

      {/* ===================================================
          FOOTER
      =================================================== */}

      <div className="mt-3 flex items-center justify-between text-xs text-muted-foreground">
        <span>
          {
            filteredLeads.length
          }{" "}
          {
            ui.leads
          }

          {filteredLeads.length !==
          leads.length
            ? ` / ${leads.length}`
            : ""}
        </span>

        <span>
          Supabase
        </span>
      </div>

      <BulkOutreachScheduleDialog
        open={
          scheduleDialogOpen
        }
        leads={
          leads
            .filter((lead) =>
              selectedIds.has(
                lead.id
              )
            )
            .map((lead) => ({
              id:
                lead.id,
              companyName:
                lead.companyName,
              contactEmail:
                lead.contactEmail,
            }))
        }
        onOpenChange={
          setScheduleDialogOpen
        }
        onScheduled={() => {
          setSelectedIds(
            new Set()
          );
          router.refresh();
        }}
      />

      {/* ===================================================
          DELETE DIALOG
      =================================================== */}

      <AlertDialog
        open={
          deleteDialogOpen
        }
        onOpenChange={
          setDeleteDialogOpen
        }
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              {selectedIds.size ===
              1
                ? text.table
                    .deleteDialogTitleOne
                : text.table.deleteDialogTitleMany.replace(
                    "{count}",
                    String(
                      selectedIds.size
                    )
                  )}
            </AlertDialogTitle>

            <AlertDialogDescription>
              {
                text.table
                  .deleteDialogDescription
              }
            </AlertDialogDescription>
          </AlertDialogHeader>

          <AlertDialogFooter>
            <AlertDialogCancel
              disabled={
                isDeleting
              }
            >
              {
                text.common
                  .cancel
              }
            </AlertDialogCancel>

            <AlertDialogAction
              type="button"
              variant="destructive"
              disabled={
                isDeleting
              }
              onClick={
                handleBulkDelete
              }
            >
              {isDeleting ? (
                <>
                  <Loader2 className="size-4 animate-spin" />

                  {
                    text.table
                      .deleting
                  }
                </>
              ) : (
                <>
                  <Trash2 className="size-4" />

                  {
                    text.table
                      .deleteLeads
                  }
                </>
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}