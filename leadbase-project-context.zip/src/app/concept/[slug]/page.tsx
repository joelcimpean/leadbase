import type {
    Metadata,
  } from "next";
  
  import {
    ArrowUpRight,
  } from "lucide-react";
  
  import {
    notFound,
  } from "next/navigation";
  
  import {
    createClient as createSupabaseClient,
  } from "@supabase/supabase-js";
  
  import {
    CustomerContactChoice,
    CustomerDesignFrame,
    PreviewVisitTracker,
  } from "./customer-design-frame";
  
  /* =========================================================
     CONFIG
  ========================================================= */
  
  export const dynamic =
    "force-dynamic";
  
  /* =========================================================
     TYPES
  ========================================================= */
  
  type ConceptPageProps = {
    params: Promise<{
      slug:
        string;
    }>;
  
    searchParams: Promise<{
      capture?:
        string;
  
      src?:
        string;
    }>;
  };
  
  type PublicPreviewRow = {
    id?:
      string;
  
    source_snapshot?:
      unknown;
  
    source_brand_name?:
      string;
  
    source_website_url?:
      string
      | null;
  
    created_at?:
      string;
  
    expires_at?:
      string
      | null;
  };
  
  type StaticDesignSnapshot = {
    version:
      3;
  
    renderMode:
      "html";
  
    html:
      string;
  
    companyName?:
      string;
  
    sourceUrl?:
      string;
  
    generationIndex?:
      number;
  
    model?:
      string;
  
    direction?:
      string;
  };
  
  /* =========================================================
     VALIDATION
  ========================================================= */
  
  const SLUG_PATTERN =
    /^[a-z0-9]+(?:-[a-z0-9]+)*$/;
  
  function isRecord(
    value:
      unknown
  ): value is Record<
    string,
    unknown
  > {
    return (
      typeof value ===
        "object" &&
      value !==
        null &&
      !Array.isArray(
        value
      )
    );
  }
  
  function getStaticDesignSnapshot(
    value:
      unknown
  ): StaticDesignSnapshot | null {
    if (
      !isRecord(
        value
      )
    ) {
      return null;
    }
  
    if (
      value.version !==
        3 ||
      value.renderMode !==
        "html"
    ) {
      return null;
    }
  
    if (
      typeof value.html !==
        "string" ||
      value.html.trim()
        .length <
        500
    ) {
      return null;
    }
  
    return value as
      unknown as
      StaticDesignSnapshot;
  }
  
  /* =========================================================
     SUPABASE
  ========================================================= */
  
  function createPublicSupabaseClient() {
    const supabaseUrl =
      process.env
        .NEXT_PUBLIC_SUPABASE_URL;
  
    const supabaseKey =
      process.env
        .NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY;
  
    if (
      !supabaseUrl ||
      !supabaseKey
    ) {
      return null;
    }
  
    return createSupabaseClient(
      supabaseUrl,
      supabaseKey,
      {
        auth: {
          persistSession:
            false,
  
          autoRefreshToken:
            false,
  
          detectSessionInUrl:
            false,
        },
      }
    );
  }
  
  /* =========================================================
     LOAD
  ========================================================= */
  
  async function loadPreview(
    slug:
      string
  ) {
    if (
      !SLUG_PATTERN.test(
        slug
      )
    ) {
      return null;
    }
  
    const supabase =
      createPublicSupabaseClient();
  
    if (
      !supabase
    ) {
      console.error(
        "Public Supabase environment variables are missing."
      );
  
      return null;
    }
  
    const {
      data,
      error,
    } =
      await supabase.rpc(
        "get_public_design_preview_by_slug",
        {
          p_slug:
            slug,
        }
      );
  
    if (
      error
    ) {
      console.error(
        "Could not load public design preview:",
        error
      );
  
      return null;
    }
  
    const row =
      Array.isArray(
        data
      )
        ? data[0] ??
          null
        : data;
  
    if (
      !row ||
      typeof row !==
        "object"
    ) {
      return null;
    }
  
    return row as
      PublicPreviewRow;
  }
  
  /* =========================================================
     METADATA
  ========================================================= */
  
  export async function generateMetadata({
    params,
  }: ConceptPageProps): Promise<Metadata> {
    const {
      slug,
    } =
      await params;
  
    const row =
      await loadPreview(
        slug
      );
  
    const companyName =
      row
        ?.source_brand_name
        ?.trim() ||
      "Unternehmen";
  
    return {
      title:
        `Designkonzept für ${companyName}`,
  
      description:
        `Persönliche Website-Vorschau für ${companyName}.`,
  
      robots: {
        index:
          false,
  
        follow:
          false,
  
        nocache:
          true,
  
        googleBot: {
          index:
            false,
  
          follow:
            false,
  
          noimageindex:
            true,
        },
      },
  
      referrer:
        "no-referrer",
    };
  }
  
  /* =========================================================
     PAGE
  ========================================================= */
  
  export default async function ConceptPage({
    params,
    searchParams,
  }: ConceptPageProps) {
    const [
      {
        slug,
      },
      resolvedSearchParams,
    ] =
      await Promise.all([
        params,
        searchParams,
      ]);
  
    const row =
      await loadPreview(
        slug
      );
  
    if (
      !row
    ) {
      notFound();
    }
  
    const snapshot =
      getStaticDesignSnapshot(
        row.source_snapshot
      );
  
    if (
      !snapshot
    ) {
      console.error(
        "Public design preview contains an invalid static design snapshot."
      );
  
      notFound();
    }
  
    const captureMode =
      resolvedSearchParams.capture ===
        "gif";
  
    const companyName =
      row
        .source_brand_name
        ?.trim() ||
      snapshot.companyName ||
      "Unternehmen";
  
    /*
     * Internal capture mode intentionally renders ONLY the
     * generated website.
     *
     * - no customer bar
     * - no visit tracker
     * - no Leadbase visit / Hot Score pollution
     *
     * This URL is used only by the server-side GIF renderer.
     */
    if (
      captureMode
    ) {
      return (
        <main className="min-h-screen bg-white">
          <CustomerDesignFrame
            title={`GIF capture · ${companyName}`}
            html={
              snapshot.html
            }
          />
        </main>
      );
    }
  
    /* =======================================================
       NORMAL CUSTOMER PREVIEW
    ======================================================= */
  
    const designerName =
      process.env
        .DESIGNER_NAME
        ?.trim() ||
      "Joel Cimpean";
  
    const portfolioUrl =
      process.env
        .DESIGNER_PORTFOLIO_URL
        ?.trim() ||
      "https://joelcimpean.com";
  
    const designerEmail =
      process.env
        .DESIGNER_EMAIL
        ?.trim() ||
      "hello@joelcimpean.com";
  
    const calendarUrl =
      process.env
        .DESIGNER_CALENDAR_URL
        ?.trim() ||
      "https://cal.com/joel-cimpean-ag9kpu/30min";
  
    const mailSubject =
      `Designvorschau für ${companyName}`;
  
    const mailBody =
      [
        "Hallo Joel,",
        "",
        `ich habe mir die Designvorschau für ${companyName} angesehen und würde mich gerne kurz dazu austauschen.`,
        "",
        "Viele Grüße",
      ].join(
        "\n"
      );
  
    const mailUrl =
      designerEmail
        ? `mailto:${designerEmail}?subject=${encodeURIComponent(
            mailSubject
          )}&body=${encodeURIComponent(
            mailBody
          )}`
        : null;
  
    return (
      <main className="min-h-screen bg-white text-neutral-950">
        <PreviewVisitTracker
          slug={
            slug
          }
        />
  
        <div className="sticky top-0 z-[100] border-b border-neutral-200 bg-white/95 text-neutral-950 shadow-[0_1px_0_rgba(0,0,0,.04)] backdrop-blur-xl">
          <div className="mx-auto flex min-h-[64px] max-w-[1440px] items-center justify-between gap-2 px-3 py-2.5 sm:min-h-[76px] sm:gap-4 sm:px-6 sm:py-3 lg:px-8">
            <div className="min-w-0 flex-1 pr-1 sm:pr-3">
              <p className="line-clamp-2 text-[8px] font-semibold uppercase leading-[1.3] tracking-[0.13em] text-neutral-500 min-[390px]:text-[9px] sm:text-[10px] sm:tracking-[0.15em]">
                Persönliches Designkonzept für
              </p>
  
              <p className="mt-1 truncate text-[13px] font-semibold leading-tight text-neutral-950 min-[390px]:text-sm sm:text-base">
                {
                  companyName
                }
              </p>
            </div>
  
            <div className="hidden shrink-0 text-right md:block">
              <p className="text-[11px] text-neutral-500">
                Erstellt von
              </p>
  
              <a
                href={
                  portfolioUrl
                }
                target="_blank"
                rel="noopener noreferrer"
                className="group mt-0.5 inline-flex items-center gap-1 text-sm font-semibold text-neutral-950 transition-opacity hover:opacity-60"
              >
                {
                  designerName
                }
  
                <ArrowUpRight className="size-3.5 transition-transform duration-300 group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
              </a>
  
              <p className="mt-0.5 text-[9px] text-neutral-400">
                Unverbindliche Designvorschau · mögliche Gestaltungsrichtung · kein finales Konzept
              </p>
            </div>
  
            <CustomerContactChoice
              companyName={
                companyName
              }
              mailUrl={
                mailUrl
              }
              calendarUrl={
                calendarUrl
              }
            />
          </div>
  
          <div className="border-t border-neutral-100 px-3 py-1.5 md:hidden">
            <div className="mx-auto flex max-w-[1440px] items-center justify-between gap-3">
              <a
                href={
                  portfolioUrl
                }
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex min-w-0 items-center gap-1 text-[9px] font-medium text-neutral-500 transition-colors hover:text-neutral-950"
              >
                <span className="truncate">
                  Erstellt von{" "}
                  <strong className="font-semibold text-neutral-700">
                    {
                      designerName
                    }
                  </strong>
                </span>
  
                <ArrowUpRight className="size-2.5 shrink-0" />
              </a>
  
              <span className="hidden shrink-0 text-[8px] text-neutral-400 min-[430px]:block">
                Unverbindliche Designvorschau · kein finales Konzept
              </span>
            </div>
          </div>
        </div>
  
        <CustomerDesignFrame
          title={`Designkonzept für ${companyName}`}
          html={
            snapshot.html
          }
        />
      </main>
    );
  }
  