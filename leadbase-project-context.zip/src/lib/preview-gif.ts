import "server-only";

import {
  GIFEncoder,
  applyPalette,
  quantize,
} from "gifenc";

import {
  PNG,
} from "pngjs";

import {
  launchServerBrowser,
} from "@/lib/server-browser";

/* =========================================================
   CONFIG
========================================================= */

/*
 * Email teaser goals:
 * - smooth enough to feel intentional
 * - slow enough to actually inspect
 * - still small enough for email
 *
 * 24 frames × 200 ms = 4.8 second loop.
 */
const WIDTH =
  640;

const HEIGHT =
  400;

const FRAME_DELAY_MS =
  200;

const MAX_COLORS =
  80;

const LOAD_TIMEOUT_MS =
  20_000;

const STABILIZE_MS =
  1_500;

/*
 * Only move through the upper part of the concept.
 * For cold outreach the hero + first sections are much more
 * valuable than quickly rushing through the whole page.
 */
const MAX_SCROLL_FRACTION =
  0.42;

/*
 * Explicit motion curve.
 *
 * - first frames hold the hero
 * - slow scroll downward
 * - short hold on the lower section
 * - slow return to hero
 * - final hold makes the loop feel seamless
 *
 * 24 frames total.
 */
const SCROLL_PROGRESS = [
  0,
  0,
  0.01,
  0.025,
  0.05,
  0.085,
  0.13,
  0.19,
  0.26,
  0.34,
  0.42,
  0.5,
  0.58,
  0.64,
  0.64,
  0.58,
  0.5,
  0.42,
  0.32,
  0.22,
  0.13,
  0.06,
  0.015,
  0,
] as const;

/* =========================================================
   TYPES
========================================================= */

export type PreviewGifResult = {
  bytes:
    Uint8Array;

  width:
    number;

  height:
    number;

  frameCount:
    number;

  durationMs:
    number;
};

/* =========================================================
   HELPERS
========================================================= */

function sleep(
  milliseconds:
    number
) {
  return new Promise<void>(
    (
      resolve
    ) => {
      setTimeout(
        resolve,
        milliseconds
      );
    }
  );
}

/* =========================================================
   GENERATE
========================================================= */

export async function generatePreviewGif(
  previewUrl:
    string
): Promise<PreviewGifResult> {
  const browser =
    await launchServerBrowser();

  try {
    const page =
      await browser.newPage({
        viewport: {
          width:
            WIDTH,

          height:
            HEIGHT,
        },

        deviceScaleFactor:
          1,
      });

    await page.setExtraHTTPHeaders({
      "x-leadbase-renderer":
        "preview-gif",
    });

    await page.goto(
      previewUrl,
      {
        waitUntil:
          "networkidle",

        timeout:
          LOAD_TIMEOUT_MS,
      }
    );

    await page.waitForSelector(
      "iframe",
      {
        timeout:
          LOAD_TIMEOUT_MS,
      }
    );

    await sleep(
      STABILIZE_MS
    );

    const pageHeight =
      await page.evaluate(
        () =>
          Math.max(
            document.documentElement
              .scrollHeight,
            document.body
              ?.scrollHeight ??
              0,
            window.innerHeight
          )
      );

    const fullAvailableScroll =
      Math.max(
        0,
        pageHeight -
          HEIGHT
      );

    const teaserScroll =
      Math.round(
        fullAvailableScroll *
          MAX_SCROLL_FRACTION
      );

    const gif =
      GIFEncoder();

    for (
      let index =
        0;
      index <
        SCROLL_PROGRESS.length;
      index +=
        1
    ) {
      const progress =
        SCROLL_PROGRESS[
          index
        ];

      const targetScroll =
        Math.round(
          teaserScroll *
            progress
        );

      await page.evaluate(
        (
          y
        ) => {
          window.scrollTo(
            0,
            y
          );
        },
        targetScroll
      );

      /*
       * Small settle time avoids capturing while browser paint
       * is still catching up to the new scroll position.
       */
      await sleep(
        75
      );

      const screenshot =
        await page.screenshot({
          type:
            "png",

          animations:
            "disabled",
        });

      const png =
        PNG.sync.read(
          screenshot
        );

      const rgba =
        new Uint8Array(
          png.data.buffer,
          png.data.byteOffset,
          png.data.byteLength
        );

      const palette =
        quantize(
          rgba,
          MAX_COLORS,
          {
            format:
              "rgb565",
          }
        );

      const indexed =
        applyPalette(
          rgba,
          palette,
          "rgb565"
        );

      gif.writeFrame(
        indexed,
        png.width,
        png.height,
        {
          palette,

          delay:
            FRAME_DELAY_MS,

          repeat:
            0,
        }
      );
    }

    gif.finish();

    const bytes =
      gif.bytes();

    if (
      bytes.byteLength <
      1000
    ) {
      throw new Error(
        "Generated GIF is unexpectedly small."
      );
    }

    return {
      bytes,

      width:
        WIDTH,

      height:
        HEIGHT,

      frameCount:
        SCROLL_PROGRESS.length,

      durationMs:
        SCROLL_PROGRESS.length *
        FRAME_DELAY_MS,
    };
  } finally {
    await browser.close();
  }
}
