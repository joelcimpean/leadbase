import "server-only";

/* =========================================================
   TYPES
========================================================= */

type BuildOutreachHtmlInput = {
  textBody: string;
  previewUrl: string;
  gifUrl: string;
};

/* =========================================================
   SAFETY
========================================================= */

function escapeHtml(
  value: string
) {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/\"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function escapeAttribute(
  value: string
) {
  return escapeHtml(value);
}

function isHttpUrl(
  value: string
) {
  try {
    const url = new URL(value);
    return url.protocol === "http:" || url.protocol === "https:";
  } catch {
    return false;
  }
}

/* =========================================================
   LINKIFY PLAIN TEXT WITHOUT CHANGING THE COPY
========================================================= */

function renderTextBlock(
  value: string
) {
  const urlPattern = /(https?:\/\/[^\s<>]+)/gi;
  const parts = value.split(urlPattern);

  return parts
    .map((part) => {
      if (isHttpUrl(part)) {
        const href = escapeAttribute(part);
        const label = escapeHtml(part);

        return `<a href="${href}" style="color:#0b57d0;text-decoration:underline;word-break:break-all;">${label}</a>`;
      }

      return escapeHtml(part);
    })
    .join("")
    .replace(/\r?\n/g, "<br>");
}

/* =========================================================
   EMAIL HTML
========================================================= */

export function buildOutreachHtmlEmail({
  textBody,
  previewUrl,
  gifUrl,
}: BuildOutreachHtmlInput) {
  if (
    !textBody.trim() ||
    !isHttpUrl(previewUrl) ||
    !isHttpUrl(gifUrl)
  ) {
    return null;
  }

  const safePreviewUrl =
    escapeAttribute(previewUrl);

  const safeGifUrl =
    escapeAttribute(gifUrl);

  const conceptUrlPattern =
    /https?:\/\/[^\s<>]+\/concept\/[^\s<>]+/i;

  const match =
    textBody.match(conceptUrlPattern);

  let before = textBody;
  let after = "";

  if (match?.index !== undefined) {
    before = textBody.slice(0, match.index).trimEnd();
    after = textBody.slice(match.index).trimStart();
  }

  const beforeHtml =
    renderTextBlock(before);

  const afterHtml =
    renderTextBlock(after);

  return `<!doctype html>
<html>
  <body style="margin:0;padding:0;background:#ffffff;color:#111111;">
    <div style="font-family:Arial,Helvetica,sans-serif;font-size:15px;line-height:1.6;color:#111111;max-width:680px;margin:0;padding:0;">
      <div>${beforeHtml}</div>

      <div style="margin:22px 0 18px 0;max-width:620px;">
        <a href="${safePreviewUrl}" style="display:block;text-decoration:none;border:0;" target="_blank">
          <img
            src="${safeGifUrl}"
            alt="Website design preview"
            width="620"
            style="display:block;width:100%;max-width:620px;height:auto;border:1px solid #e5e7eb;border-radius:12px;"
          >
        </a>
      </div>

      ${afterHtml ? `<div>${afterHtml}</div>` : ""}
    </div>
  </body>
</html>`;
}
